package com.movies.myapplication.ui.browse

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.movies.myapplication.data.model.DiscoverFilter
import com.movies.myapplication.data.model.Genre
import com.movies.myapplication.data.model.Media
import com.movies.myapplication.data.model.MediaType
import com.movies.myapplication.ui.components.CircleIconButton
import com.movies.myapplication.ui.components.PagedMediaGrid
import com.movies.myapplication.ui.components.Pill
import com.movies.myapplication.ui.components.SearchField
import com.movies.myapplication.ui.components.TopBar
import com.movies.myapplication.ui.navigation.BrowseRoute
import com.movies.myapplication.ui.navigation.CategoryRoute
import com.movies.myapplication.ui.rememberStore
import com.movies.myapplication.ui.theme.AppIcons

/** Search screen for movies or TV shows: search box, filters, and genre buttons that open a category. */
@Composable
fun BrowseScreen(route: BrowseRoute, onOpenMedia: (Media) -> Unit, onNavigate: (Any) -> Unit, onBack: () -> Unit) {
    val store = rememberStore { BrowseStore(it.mediaRepository, route.type, DiscoverFilter(), loadGenres = true) }
    val state by store.state.collectAsStateWithLifecycle()
    val onIntent = store::onIntent

    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize()) {
            TopBar(route.title ?: if (route.type == MediaType.MOVIE) "Movie" else "TV Shows", onBack)
            Row(
                Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                SearchField(
                    value = state.query,
                    onValueChange = { onIntent(BrowseIntent.QueryChanged(it)) },
                    modifier = Modifier.weight(1f),
                )
                Spacer(Modifier.width(12.dp))
                CircleIconButton(AppIcons.Tune, "Filters", { onIntent(BrowseIntent.OpenFilters) }, size = 52.dp, showBadge = !state.filter.isDefault)
            }
            GenreChips(state.genres) { genre -> onNavigate(CategoryRoute.genre(route.type, genre)) }
            PagedMediaGrid(
                content = state,
                onLoadMore = { onIntent(BrowseIntent.LoadMore) },
                onRetry = { onIntent(BrowseIntent.Retry) },
                onOpenMedia = onOpenMedia,
            )
        }
        FilterPanel(
            visible = state.showFilters,
            filter = state.filter,
            genres = state.genres,
            providers = state.providers,
            isSearching = state.query.isNotBlank(),
            onRegionChange = { onIntent(BrowseIntent.RegionChanged(it)) },
            onApply = { onIntent(BrowseIntent.ApplyFilter(it)) },
            onDismiss = { onIntent(BrowseIntent.CloseFilters) },
        )
    }
}

@Composable
private fun GenreChips(genres: List<Genre>, onOpen: (Genre) -> Unit) {
    if (genres.isEmpty()) return
    LazyRow(
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 10.dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        items(genres, key = { it.id }) { genre ->
            Pill(genre.name, selected = false, onClick = { onOpen(genre) })
        }
    }
}
