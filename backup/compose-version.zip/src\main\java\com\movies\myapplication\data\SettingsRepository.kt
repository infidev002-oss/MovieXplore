package com.movies.myapplication.data

import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.core.stringPreferencesKey
import com.movies.myapplication.data.model.DiscoverFilter
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.io.IOException

/** Small user choices that should survive restarts. */
class SettingsRepository(private val dataStore: DataStore<Preferences>, private val scope: CoroutineScope) {

    /** The country last picked in the watch-availability panel (ISO 3166-1 code). */
    val watchCountry: StateFlow<String> = dataStore.data
        .catch { if (it is IOException) emit(emptyPreferences()) else throw it }
        .map { it[WATCH_COUNTRY] ?: DiscoverFilter.DEFAULT_WATCH_REGION }
        .stateIn(scope, SharingStarted.Eagerly, DiscoverFilter.DEFAULT_WATCH_REGION)

    fun setWatchCountry(code: String) {
        scope.launch { dataStore.edit { it[WATCH_COUNTRY] = code } }
    }

    private companion object {
        val WATCH_COUNTRY = stringPreferencesKey("watch_country")
    }
}
