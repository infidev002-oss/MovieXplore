package com.movies.myapplication.ui.navigation

import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue

/** Counts taps on the bottom-bar tabs; tab screens watch it to return to the top. */
val LocalTabSelections = compositionLocalOf { 0 }

/**
 * Runs [scrollToTop] when the user opens this tab from the bottom bar, or taps it again while on it.
 * Coming back from a screen opened inside the tab (Back from a movie) keeps the scroll position:
 * the last handled count is saved with the screen, so only a new tab tap differs from it.
 */
@Composable
fun ScrollToTopOnTabSelect(scrollToTop: suspend () -> Unit) {
    val selections = LocalTabSelections.current
    var handled by rememberSaveable { mutableIntStateOf(selections) }
    val currentScrollToTop by rememberUpdatedState(scrollToTop)
    LaunchedEffect(selections) {
        if (selections != handled) {
            handled = selections
            currentScrollToTop()
        }
    }
}
