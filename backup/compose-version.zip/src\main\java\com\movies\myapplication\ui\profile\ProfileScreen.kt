package com.movies.myapplication.ui.profile

import android.content.Context
import android.content.Intent
import android.widget.Toast
import androidx.annotation.StringRes
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.net.toUri
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import com.movies.myapplication.R
import com.movies.myapplication.data.Account
import com.movies.myapplication.data.AccountRepository
import com.movies.myapplication.data.WatchlistRepository
import com.movies.myapplication.ui.components.ArtworkImage
import com.movies.myapplication.ui.components.BottomBarSpace
import com.movies.myapplication.ui.components.PrimaryButton
import com.movies.myapplication.ui.components.StatusBarScrim
import com.movies.myapplication.ui.components.TopBar
import com.movies.myapplication.ui.mvi.CollectEffects
import com.movies.myapplication.ui.mvi.MviStore
import com.movies.myapplication.ui.navigation.ScrollToTopOnTabSelect
import com.movies.myapplication.ui.rememberStore
import com.movies.myapplication.ui.theme.AppColors
import com.movies.myapplication.ui.theme.AppIcons
import kotlinx.coroutines.launch

data class ProfileUiState(
    val account: Account? = null,
    val showLogin: Boolean = false,
    val isSigningIn: Boolean = false,
    val confirmDelete: Boolean = false,
)

sealed interface ProfileIntent {
    data object OpenLogin : ProfileIntent
    data object DismissLogin : ProfileIntent
    data object ContinueAsGuest : ProfileIntent
    data object ContinueWithGoogle : ProfileIntent
    data class GoogleSignInFinished(val result: GoogleSignInResult) : ProfileIntent
    data object Logout : ProfileIntent
    data object RequestDelete : ProfileIntent
    data object DismissDelete : ProfileIntent
    data object ConfirmDelete : ProfileIntent
}

/** Work that needs an Activity [Context], so the screen performs it. */
sealed interface ProfileEffect {
    data object LaunchGoogleSignIn : ProfileEffect
    data object ClearGoogleCredentials : ProfileEffect
    data class ShowMessage(val message: String) : ProfileEffect
}

class ProfileStore(
    private val accounts: AccountRepository,
    private val watchlist: WatchlistRepository,
) : MviStore<ProfileUiState, ProfileIntent, ProfileEffect>(ProfileUiState()) {

    init {
        viewModelScope.launch { accounts.account.collect { account -> reduce { copy(account = account) } } }
    }

    override fun onIntent(intent: ProfileIntent) {
        when (intent) {
            ProfileIntent.OpenLogin -> reduce { copy(showLogin = true) }
            ProfileIntent.DismissLogin -> reduce { copy(showLogin = false) }
            ProfileIntent.ContinueAsGuest -> {
                accounts.signIn(Account(name = "Guest", email = null, photoUrl = null, isGuest = true))
                reduce { copy(showLogin = false) }
            }
            ProfileIntent.ContinueWithGoogle -> {
                if (currentState.isSigningIn) return
                reduce { copy(isSigningIn = true) }
                postEffect(ProfileEffect.LaunchGoogleSignIn)
            }
            is ProfileIntent.GoogleSignInFinished -> {
                reduce { copy(isSigningIn = false) }
                when (val result = intent.result) {
                    is GoogleSignInResult.Success -> {
                        accounts.signIn(result.account)
                        reduce { copy(showLogin = false) }
                    }
                    is GoogleSignInResult.Failed -> postEffect(ProfileEffect.ShowMessage(result.message))
                    GoogleSignInResult.Cancelled -> Unit
                }
            }
            ProfileIntent.Logout -> signOut()
            ProfileIntent.RequestDelete -> reduce { copy(confirmDelete = true) }
            ProfileIntent.DismissDelete -> reduce { copy(confirmDelete = false) }
            ProfileIntent.ConfirmDelete -> {
                watchlist.clear()
                signOut()
                reduce { copy(confirmDelete = false) }
            }
        }
    }

    private fun signOut() {
        accounts.signOut()
        postEffect(ProfileEffect.ClearGoogleCredentials)
    }
}

/** Account tab: sign-in card or the signed-in user, app links, and the TMDB attribution. */
@Composable
fun ProfileScreen() {
    val store = rememberStore { ProfileStore(it.account, it.watchlist) }
    val state by store.state.collectAsStateWithLifecycle()
    val account = state.account
    val context = LocalContext.current
    val onIntent = store::onIntent

    CollectEffects(store.effects) { effect ->
        when (effect) {
            ProfileEffect.LaunchGoogleSignIn -> {
                // Report back even if the screen leaves mid sign-in, so the busy state never sticks.
                var result: GoogleSignInResult = GoogleSignInResult.Cancelled
                try {
                    result = signInWithGoogle(context)
                } finally {
                    onIntent(ProfileIntent.GoogleSignInFinished(result))
                }
            }
            ProfileEffect.ClearGoogleCredentials -> clearGoogleSignIn(context)
            is ProfileEffect.ShowMessage -> Toast.makeText(context, effect.message, Toast.LENGTH_LONG).show()
        }
    }

    val scrollState = rememberScrollState()
    ScrollToTopOnTabSelect { scrollState.scrollTo(0) }
    val scrolled by remember { derivedStateOf { scrollState.value > 0 } }

    Box(Modifier.fillMaxSize()) {
        Column(
            Modifier
                .fillMaxSize()
                .verticalScroll(scrollState)
                .padding(bottom = BottomBarSpace),
        ) {
            TopBar("Account", onBack = null)
            Column(
                Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                if (account == null) SignInCard(onLogin = { onIntent(ProfileIntent.OpenLogin) }) else UserHeader(account)

                AccountRow(AppIcons.ThumbUp, "Rate Us") {
                    context.openLink("market://details?id=${context.packageName}", "https://play.google.com/store/apps/details?id=${context.packageName}")
                }
                AccountRow(AppIcons.Privacy, "Privacy Policy") { context.openConfiguredLink(R.string.privacy_policy_url) }
                AccountRow(AppIcons.Terms, "Terms & Conditions") { context.openConfiguredLink(R.string.terms_url) }
                AccountRow(AppIcons.Feedback, "Feedback") { context.sendFeedback() }
                if (account != null) {
                    AccountRow(AppIcons.Logout, "Logout") { onIntent(ProfileIntent.Logout) }
                    AccountRow(AppIcons.PersonRemove, "Delete Account") { onIntent(ProfileIntent.RequestDelete) }
                }
                TmdbLicenseCard { context.openLink("https://www.themoviedb.org") }
            }
        }
        StatusBarScrim(visible = scrolled)
    }

    if (state.showLogin) {
        LoginSheet(
            busy = state.isSigningIn,
            onGoogle = { onIntent(ProfileIntent.ContinueWithGoogle) },
            onGuest = { onIntent(ProfileIntent.ContinueAsGuest) },
            onDismiss = { onIntent(ProfileIntent.DismissLogin) },
        )
    }

    if (state.confirmDelete) {
        AlertDialog(
            onDismissRequest = { onIntent(ProfileIntent.DismissDelete) },
            title = { Text("Delete account?") },
            text = { Text("This signs you out and permanently removes your watchlist and profile from this phone.") },
            confirmButton = {
                TextButton(onClick = { onIntent(ProfileIntent.ConfirmDelete) }) { Text("Delete", color = AppColors.Year) }
            },
            dismissButton = { TextButton(onClick = { onIntent(ProfileIntent.DismissDelete) }) { Text("Cancel") } },
            containerColor = AppColors.Surface,
        )
    }
}

@Composable
private fun SignInCard(onLogin: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(AppColors.SurfaceHigh)
            .clickable(onClick = onLogin)
            .padding(14.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(AppIcons.AccountCircle, contentDescription = null, modifier = Modifier.size(52.dp))
        Column(
            Modifier
                .weight(1f)
                .padding(horizontal = 12.dp),
        ) {
            Text("Sign in to Account", style = MaterialTheme.typography.titleMedium)
            Text(
                "Sign in with Google or continue as a guest.",
                style = MaterialTheme.typography.bodySmall,
                color = AppColors.TextSecondary,
            )
        }
        Text("Login", style = MaterialTheme.typography.labelLarge, color = AppColors.Year)
    }
}

@Composable
private fun UserHeader(account: Account) {
    Column(
        Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        ArtworkImage(
            url = account.photoUrl,
            contentDescription = account.name,
            placeholder = AppIcons.Person,
            modifier = Modifier
                .size(96.dp)
                .clip(CircleShape),
        )
        Text(account.name, style = MaterialTheme.typography.headlineSmall, modifier = Modifier.padding(top = 10.dp))
        account.email?.let {
            Text(it, style = MaterialTheme.typography.bodyMedium, color = AppColors.TextSecondary)
        }
    }
}

@Composable
private fun AccountRow(icon: ImageVector, label: String, onClick: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .background(AppColors.SurfaceHigh)
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(icon, contentDescription = null, modifier = Modifier.size(24.dp))
        Text(
            label,
            style = MaterialTheme.typography.bodyLarge,
            modifier = Modifier
                .weight(1f)
                .padding(horizontal = 16.dp),
        )
        Icon(AppIcons.ChevronRight, contentDescription = null)
    }
}

@Composable
private fun TmdbLicenseCard(onClick: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(AppColors.SurfaceHigh)
            .clickable(onClick = onClick)
            .padding(14.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Image(
            painterResource(R.drawable.tmdb_logo),
            contentDescription = "The Movie Database logo",
            modifier = Modifier.size(width = 68.dp, height = 49.dp),
        )
        Column(Modifier.padding(start = 14.dp)) {
            Text("TMDB License", style = MaterialTheme.typography.titleMedium)
            Text(
                "This app uses the TMDB API but is not endorsed or certified by TMDB.",
                style = MaterialTheme.typography.bodySmall,
                color = AppColors.TextSecondary,
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun LoginSheet(busy: Boolean, onGoogle: () -> Unit, onGuest: () -> Unit, onDismiss: () -> Unit) {
    ModalBottomSheet(onDismissRequest = onDismiss, containerColor = AppColors.Surface) {
        Column(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 24.dp)
                .navigationBarsPadding()
                .padding(bottom = 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Text("Sign in", style = MaterialTheme.typography.titleLarge)
            Spacer(Modifier.height(20.dp))
            Button(
                onClick = onGoogle,
                enabled = !busy,
                shape = RoundedCornerShape(50),
                colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = AppColors.Background),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp),
            ) {
                Text(if (busy) "Signing in…" else "Continue with Google", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            }
            Spacer(Modifier.height(12.dp))
            PrimaryButton("Continue as Guest", onGuest, Modifier.fillMaxWidth(), enabled = !busy)
        }
    }
}

/** Opens [url] (e.g. a Play Store `market://` link), falling back to [fallbackUrl]; never crashes if nothing can open it. */
private fun Context.openLink(url: String, fallbackUrl: String? = null) {
    val opened = runCatching { startActivity(Intent(Intent.ACTION_VIEW, url.toUri())) }.isSuccess
    if (!opened && fallbackUrl != null) runCatching { startActivity(Intent(Intent.ACTION_VIEW, fallbackUrl.toUri())) }
}

private fun Context.openConfiguredLink(@StringRes urlRes: Int) {
    val url = getString(urlRes)
    if (url.isBlank()) notAvailable() else openLink(url)
}

private fun Context.sendFeedback() {
    val email = getString(R.string.feedback_email)
    if (email.isBlank()) return notAvailable()
    val intent = Intent(Intent.ACTION_SENDTO, "mailto:".toUri())
        .putExtra(Intent.EXTRA_EMAIL, arrayOf(email))
        .putExtra(Intent.EXTRA_SUBJECT, "Feedback: ${getString(R.string.app_name)}")
    runCatching { startActivity(intent) }
}

private fun Context.notAvailable() = Toast.makeText(this, "Not available yet", Toast.LENGTH_SHORT).show()
