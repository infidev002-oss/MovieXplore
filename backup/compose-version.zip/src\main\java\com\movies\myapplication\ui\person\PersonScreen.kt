package com.movies.myapplication.ui.person

import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import com.movies.myapplication.data.MediaRepository
import com.movies.myapplication.data.model.Media
import com.movies.myapplication.data.model.Person
import com.movies.myapplication.data.model.TmdbImage
import com.movies.myapplication.ui.components.ArtworkImage
import com.movies.myapplication.ui.components.CircleIconButton
import com.movies.myapplication.ui.components.ExpandableText
import com.movies.myapplication.ui.components.LoadingState
import com.movies.myapplication.ui.components.MessageState
import com.movies.myapplication.ui.components.PosterImage
import com.movies.myapplication.ui.components.SectionHeader
import com.movies.myapplication.ui.mvi.MviStore
import com.movies.myapplication.ui.navigation.PersonRoute
import com.movies.myapplication.ui.rememberStore
import com.movies.myapplication.ui.safeCall
import com.movies.myapplication.ui.theme.AppColors
import com.movies.myapplication.ui.theme.AppIcons
import com.movies.myapplication.ui.toUserMessage
import kotlinx.coroutines.launch

data class PersonUiState(val person: Person? = null, val isLoading: Boolean = true, val error: String? = null)

sealed interface PersonIntent {
    data object Retry : PersonIntent
}

class PersonStore(
    private val repository: MediaRepository,
    private val id: Int,
) : MviStore<PersonUiState, PersonIntent, Nothing>(PersonUiState()) {

    init {
        load()
    }

    override fun onIntent(intent: PersonIntent) {
        when (intent) {
            PersonIntent.Retry -> load()
        }
    }

    private fun load() {
        viewModelScope.launch {
            reduce { copy(isLoading = true, error = null) }
            safeCall { repository.person(id) }
                .onSuccess { person -> reduce { copy(person = person, isLoading = false) } }
                .onFailure { e -> reduce { copy(isLoading = false, error = e.toUserMessage()) } }
        }
    }
}

@Composable
fun PersonScreen(route: PersonRoute, onBack: () -> Unit, onOpenMedia: (Media) -> Unit) {
    val store = rememberStore { PersonStore(it.mediaRepository, route.id) }
    val state by store.state.collectAsStateWithLifecycle()
    val person = state.person
    val error = state.error

    Box(Modifier.fillMaxSize()) {
        when {
            person != null -> PersonContent(person, onOpenMedia)
            state.isLoading -> LoadingState()
            error != null -> MessageState(error, onRetry = { store.onIntent(PersonIntent.Retry) })
        }
        CircleIconButton(
            AppIcons.Back,
            contentDescription = "Back",
            onClick = onBack,
            size = 42.dp,
            modifier = Modifier
                .statusBarsPadding()
                .padding(12.dp),
        )
    }
}

@Composable
private fun PersonContent(person: Person, onOpenMedia: (Media) -> Unit) {
    LazyColumn(
        contentPadding = PaddingValues(bottom = 32.dp),
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .navigationBarsPadding(),
    ) {
        item {
            Column(
                Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                ArtworkImage(
                    url = TmdbImage.posterLarge(person.profilePath),
                    contentDescription = person.name,
                    placeholder = AppIcons.Person,
                    modifier = Modifier
                        .padding(top = 16.dp)
                        .size(170.dp)
                        .clip(CircleShape)
                        .border(2.dp, Color.White, CircleShape),
                )
                Text(person.name, style = MaterialTheme.typography.headlineMedium, textAlign = TextAlign.Center, modifier = Modifier.padding(top = 12.dp))
                person.birthday?.let {
                    Text("Born:", style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(top = 8.dp))
                    Text(it, style = MaterialTheme.typography.bodyLarge)
                }
                person.placeOfBirth?.let {
                    Text(it, style = MaterialTheme.typography.bodyMedium, color = AppColors.TextSecondary, textAlign = TextAlign.Center)
                }
            }
        }
        if (person.biography.isNotBlank()) {
            item {
                Column(Modifier.padding(16.dp)) {
                    Text("Biography:", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    ExpandableText(person.biography, Modifier.padding(top = 8.dp), collapsedLines = 7)
                }
            }
        }
        item { CreditsRow("Movies", person.movies, onOpenMedia) }
        item { CreditsRow("TV Shows", person.tvShows, onOpenMedia) }
    }
}

@Composable
private fun CreditsRow(title: String, items: List<Media>, onOpenMedia: (Media) -> Unit) {
    if (items.isEmpty()) return
    SectionHeader(title)
    LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        items(items, key = { it.key }) { media ->
            PosterImage(media.posterPath, media.title, onClick = { onOpenMedia(media) }, modifier = Modifier.width(110.dp))
        }
    }
}
