package com.movies.myapplication.data

import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.MutablePreferences
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.core.stringPreferencesKey
import com.movies.myapplication.data.model.Media
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.serialization.json.Json
import java.io.IOException

class WatchlistRepository(
    private val dataStore: DataStore<Preferences>,
    private val json: Json,
    private val scope: CoroutineScope,
) {
    val items: StateFlow<List<Media>> = dataStore.data
        .catch { if (it is IOException) emit(emptyPreferences()) else throw it }
        .map { decode(it) }
        .stateIn(scope, SharingStarted.Eagerly, emptyList())

    val keys: StateFlow<Set<String>> = items
        .map { list -> list.mapTo(HashSet()) { it.key } }
        .stateIn(scope, SharingStarted.Eagerly, emptySet())

    fun toggle(media: Media) {
        scope.launch {
            dataStore.edit { prefs ->
                val current = decode(prefs)
                val updated = if (current.any { it.key == media.key }) {
                    current.filterNot { it.key == media.key }
                } else {
                    listOf(media) + current
                }
                prefs.write(updated)
            }
        }
    }

    fun clear() {
        scope.launch { dataStore.edit { it.remove(KEY) } }
    }

    private fun decode(prefs: Preferences): List<Media> =
        prefs[KEY]?.let { runCatching { json.decodeFromString<List<Media>>(it) }.getOrNull() }.orEmpty()

    private fun MutablePreferences.write(list: List<Media>) {
        this[KEY] = json.encodeToString(list)
    }

    private companion object {
        val KEY = stringPreferencesKey("watchlist")
    }
}
