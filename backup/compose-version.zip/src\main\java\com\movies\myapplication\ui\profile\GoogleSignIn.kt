package com.movies.myapplication.ui.profile

import android.content.Context
import androidx.credentials.ClearCredentialStateRequest
import androidx.credentials.CredentialManager
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import androidx.credentials.exceptions.GetCredentialCancellationException
import androidx.credentials.exceptions.GetCredentialException
import androidx.credentials.exceptions.NoCredentialException
import com.google.android.libraries.identity.googleid.GetSignInWithGoogleOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import com.google.android.libraries.identity.googleid.GoogleIdTokenParsingException
import com.movies.myapplication.BuildConfig
import com.movies.myapplication.data.Account
import kotlinx.coroutines.CancellationException

sealed interface GoogleSignInResult {
    data class Success(val account: Account) : GoogleSignInResult

    /** The user closed the Google sheet; nothing to report. */
    data object Cancelled : GoogleSignInResult

    data class Failed(val message: String) : GoogleSignInResult
}

private val googleCredentialTypes = setOf(
    GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL,
    GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_SIWG_CREDENTIAL,
)

/**
 * Shows the system "Sign in with Google" sheet. [activityContext] must be an Activity so the sheet can appear.
 * Only the profile details are used; the ID token is not stored or sent anywhere.
 */
suspend fun signInWithGoogle(activityContext: Context): GoogleSignInResult {
    val clientId = BuildConfig.GOOGLE_WEB_CLIENT_ID
    if (clientId.isBlank()) return GoogleSignInResult.Failed("Google sign-in isn't set up yet. Continue as a guest for now.")

    val request = GetCredentialRequest.Builder()
        .addCredentialOption(GetSignInWithGoogleOption.Builder(clientId).build())
        .build()
    return try {
        val credential = CredentialManager.create(activityContext).getCredential(activityContext, request).credential
        if (credential !is CustomCredential || credential.type !in googleCredentialTypes) {
            return GoogleSignInResult.Failed("Google sign-in returned an unexpected response.")
        }
        val google = GoogleIdTokenCredential.createFrom(credential.data)
        GoogleSignInResult.Success(
            Account(
                name = google.displayName ?: google.givenName ?: google.email ?: "Google user",
                email = google.email,
                photoUrl = google.profilePictureUri?.toString(),
                isGuest = false,
            ),
        )
    } catch (e: CancellationException) {
        throw e
    } catch (_: GetCredentialCancellationException) {
        GoogleSignInResult.Cancelled
    } catch (_: NoCredentialException) {
        GoogleSignInResult.Failed("No Google account found on this phone.")
    } catch (_: GetCredentialException) {
        GoogleSignInResult.Failed("Google sign-in failed. Please try again.")
    } catch (_: GoogleIdTokenParsingException) {
        GoogleSignInResult.Failed("Google sign-in failed. Please try again.")
    }
}

/** Tells Credential Manager the user signed out, so the next sign-in shows the account picker again. */
suspend fun clearGoogleSignIn(context: Context) {
    runCatching { CredentialManager.create(context).clearCredentialState(ClearCredentialStateRequest()) }
}
