package com.movies.myapplication.data.remote

import retrofit2.http.GET
import retrofit2.http.Path
import retrofit2.http.Query
import retrofit2.http.QueryMap

interface TmdbApi {

    @GET("trending/{type}/{window}")
    suspend fun trending(
        @Path("type") type: String,
        @Path("window") window: String,
        @Query("page") page: Int = 1,
    ): PageDto<MediaDto>

    @GET("{type}/popular")
    suspend fun popular(@Path("type") type: String, @Query("page") page: Int = 1): PageDto<MediaDto>

    @GET("{type}/top_rated")
    suspend fun topRated(@Path("type") type: String, @Query("page") page: Int = 1): PageDto<MediaDto>

    @GET("discover/{type}")
    suspend fun discover(
        @Path("type") type: String,
        @QueryMap params: Map<String, String>,
    ): PageDto<MediaDto>

    @GET("search/{type}")
    suspend fun search(
        @Path("type") type: String,
        @QueryMap params: Map<String, String>,
    ): PageDto<MediaDto>

    @GET("genre/{type}/list")
    suspend fun genres(@Path("type") type: String): GenreListDto

    @GET("{type}/{id}")
    suspend fun details(
        @Path("type") type: String,
        @Path("id") id: Int,
        @Query("append_to_response") append: String? = null,
    ): DetailsDto

    @GET("tv/{id}/season/{season}")
    suspend fun season(@Path("id") tvId: Int, @Path("season") season: Int): SeasonDto

    @GET("tv/{id}/season/{season}/episode/{episode}")
    suspend fun episode(
        @Path("id") tvId: Int,
        @Path("season") season: Int,
        @Path("episode") episode: Int,
        @Query("append_to_response") append: String = "videos",
    ): EpisodeDetailsDto

    @GET("person/{id}")
    suspend fun person(
        @Path("id") id: Int,
        @Query("append_to_response") append: String = "combined_credits",
    ): PersonDto

    @GET("watch/providers/{type}")
    suspend fun providers(
        @Path("type") type: String,
        @Query("watch_region") region: String,
    ): ProviderListDto

    /** Where one title can be watched, for every country at once. */
    @GET("{type}/{id}/watch/providers")
    suspend fun watchProviders(@Path("type") type: String, @Path("id") id: Int): WatchProvidersDto

    /** Every country TMDB has watch-provider data for. */
    @GET("watch/providers/regions")
    suspend fun watchRegions(): WatchRegionListDto
}
