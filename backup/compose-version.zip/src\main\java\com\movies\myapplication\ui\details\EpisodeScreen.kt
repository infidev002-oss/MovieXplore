package com.movies.myapplication.ui.details

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import com.movies.myapplication.data.MediaRepository
import com.movies.myapplication.data.model.EpisodeDetails
import com.movies.myapplication.data.model.TmdbImage
import com.movies.myapplication.ui.components.ArtworkImage
import com.movies.myapplication.ui.components.CircleIconButton
import com.movies.myapplication.ui.components.ExpandableText
import com.movies.myapplication.ui.components.LoadingState
import com.movies.myapplication.ui.components.MessageState
import com.movies.myapplication.ui.components.PrimaryButton
import com.movies.myapplication.ui.components.Rating
import com.movies.myapplication.ui.components.StatusBarScrim
import com.movies.myapplication.ui.formatDate
import com.movies.myapplication.ui.formatRuntime
import com.movies.myapplication.ui.mvi.MviStore
import com.movies.myapplication.ui.navigation.EpisodeRoute
import com.movies.myapplication.ui.navigation.PersonRoute
import com.movies.myapplication.ui.playOnYouTube
import com.movies.myapplication.ui.rememberStore
import com.movies.myapplication.ui.safeCall
import com.movies.myapplication.ui.searchOnYouTube
import com.movies.myapplication.ui.theme.AppColors
import com.movies.myapplication.ui.theme.AppIcons
import com.movies.myapplication.ui.toUserMessage
import kotlinx.coroutines.launch

data class EpisodeUiState(val episode: EpisodeDetails? = null, val isLoading: Boolean = true, val error: String? = null)

sealed interface EpisodeIntent {
    data object Retry : EpisodeIntent
}

class EpisodeStore(
    private val repository: MediaRepository,
    private val route: EpisodeRoute,
) : MviStore<EpisodeUiState, EpisodeIntent, Nothing>(EpisodeUiState()) {

    init {
        load()
    }

    override fun onIntent(intent: EpisodeIntent) {
        when (intent) {
            EpisodeIntent.Retry -> load()
        }
    }

    private fun load() {
        viewModelScope.launch {
            reduce { copy(isLoading = true, error = null) }
            safeCall { repository.episode(route.tvId, route.season, route.episode) }
                .onSuccess { episode -> reduce { copy(episode = episode, isLoading = false) } }
                .onFailure { e -> reduce { copy(isLoading = false, error = e.toUserMessage()) } }
        }
    }
}

@Composable
fun EpisodeScreen(route: EpisodeRoute, onBack: () -> Unit, onNavigate: (Any) -> Unit) {
    val store = rememberStore { EpisodeStore(it.mediaRepository, route) }
    val state by store.state.collectAsStateWithLifecycle()
    val episode = state.episode
    val error = state.error

    Box(Modifier.fillMaxSize()) {
        when {
            episode != null -> EpisodeContent(route, episode, onNavigate)
            state.isLoading -> LoadingState()
            error != null -> MessageState(error, onRetry = { store.onIntent(EpisodeIntent.Retry) })
        }
        CircleIconButton(
            AppIcons.Back,
            contentDescription = "Back",
            onClick = onBack,
            size = 42.dp,
            modifier = Modifier
                .statusBarsPadding()
                .padding(12.dp),
        )
    }
}

@Composable
private fun EpisodeContent(route: EpisodeRoute, episode: EpisodeDetails, onNavigate: (Any) -> Unit) {
    val context = LocalContext.current
    val listState = rememberLazyListState()
    val scrolledPastArt by remember { derivedStateOf { listState.firstVisibleItemIndex > 0 } }

    LazyColumn(
        state = listState,
        contentPadding = PaddingValues(bottom = 32.dp),
        modifier = Modifier
            .fillMaxSize()
            .navigationBarsPadding(),
    ) {
        item {
            Box(
                Modifier
                    .fillMaxWidth()
                    .aspectRatio(16f / 10f),
            ) {
                ArtworkImage(
                    url = TmdbImage.stillLarge(episode.stillPath) ?: TmdbImage.backdrop(route.backdropPath),
                    contentDescription = episode.name,
                    placeholder = AppIcons.Movie,
                    modifier = Modifier.fillMaxSize(),
                )
                Box(
                    Modifier
                        .fillMaxSize()
                        .background(Brush.verticalGradient(0.55f to Color.Transparent, 1f to AppColors.Background)),
                )
            }
        }
        item {
            Column(Modifier.padding(horizontal = 16.dp)) {
                Text(
                    "${route.showName}  •  Season ${episode.season}, Episode ${episode.number}",
                    style = MaterialTheme.typography.bodyMedium,
                    color = AppColors.TextSecondary,
                )
                Text(episode.name, style = MaterialTheme.typography.headlineMedium, modifier = Modifier.padding(top = 4.dp))
                Row(Modifier.padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    if (episode.rating > 0) {
                        Rating(episode.rating)
                        Spacer(Modifier.width(12.dp))
                    }
                    Text(
                        listOfNotNull(formatDate(episode.airDate), formatRuntime(episode.runtime)).joinToString("  •  "),
                        style = MaterialTheme.typography.bodyMedium,
                        color = AppColors.Primary,
                    )
                }
                if (episode.overview.isNotBlank()) {
                    ExpandableText(episode.overview, Modifier.padding(top = 14.dp), collapsedLines = 5)
                }
                PrimaryButton(
                    text = "Watch on YouTube",
                    // Play the episode's own video when TMDB has one; otherwise search YouTube for this episode.
                    onClick = {
                        val video = episode.videos.firstOrNull()
                        if (video != null) {
                            context.playOnYouTube(video)
                        } else {
                            context.searchOnYouTube("${route.showName} S${episode.season} E${episode.number} ${episode.name}")
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 16.dp),
                )
                Spacer(Modifier.height(8.dp))
            }
        }
        item { TrailersSection(episode.videos) }
        item { CreditsSection("Cast & Crew", episode.credits) { onNavigate(PersonRoute(it)) } }
    }
    // Drawn before EpisodeScreen's back button, so the button stays on top of it.
    StatusBarScrim(visible = scrolledPastArt)
}
