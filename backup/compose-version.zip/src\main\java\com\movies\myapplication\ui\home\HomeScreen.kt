package com.movies.myapplication.ui.home

import android.widget.Toast
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import coil3.compose.AsyncImage
import com.movies.myapplication.data.MediaRepository
import com.movies.myapplication.data.WatchlistRepository
import com.movies.myapplication.data.model.Media
import com.movies.myapplication.data.model.MediaType
import com.movies.myapplication.data.model.TmdbImage
import com.movies.myapplication.ui.components.BottomBarSpace
import com.movies.myapplication.ui.components.HomeSkeleton
import com.movies.myapplication.ui.components.InfoCard
import com.movies.myapplication.ui.components.MediaRow
import com.movies.myapplication.ui.components.MessageState
import com.movies.myapplication.ui.components.StatusBarScrim
import com.movies.myapplication.ui.mvi.CollectEffects
import com.movies.myapplication.ui.mvi.MviStore
import com.movies.myapplication.ui.navigation.BrowseRoute
import com.movies.myapplication.ui.navigation.CategoryList
import com.movies.myapplication.ui.navigation.CategoryRoute
import com.movies.myapplication.ui.navigation.ScrollToTopOnTabSelect
import com.movies.myapplication.ui.rememberStore
import com.movies.myapplication.ui.safeCall
import com.movies.myapplication.ui.theme.AppColors
import com.movies.myapplication.ui.toUserMessage
import dev.chrisbanes.haze.hazeSource
import dev.chrisbanes.haze.rememberHazeState
import kotlinx.coroutines.Job
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

/** A Home row; its "see all" arrow opens [category], whose title the row shares. */
data class HomeSection(val category: CategoryRoute, val items: List<Media>) {
    val title: String get() = category.title
}

data class HomeUiState(
    val hero: List<Media> = emptyList(),
    val sections: List<HomeSection> = emptyList(),
    val savedKeys: Set<String> = emptySet(),
    val isLoading: Boolean = true,
    /** A pull-to-refresh is running; the current rows stay on screen meanwhile. */
    val isRefreshing: Boolean = false,
    val error: String? = null,
)

sealed interface HomeIntent {
    data object Retry : HomeIntent
    data object Refresh : HomeIntent
    data class ToggleSave(val media: Media) : HomeIntent
}

sealed interface HomeEffect {
    data class ShowMessage(val message: String) : HomeEffect
}

class HomeStore(
    private val repository: MediaRepository,
    private val watchlist: WatchlistRepository,
) : MviStore<HomeUiState, HomeIntent, HomeEffect>(HomeUiState()) {

    private var loadJob: Job? = null

    init {
        viewModelScope.launch { watchlist.keys.collect { keys -> reduce { copy(savedKeys = keys) } } }
        load(refresh = false)
    }

    override fun onIntent(intent: HomeIntent) {
        when (intent) {
            HomeIntent.Retry -> load(refresh = false)
            HomeIntent.Refresh -> load(refresh = true)
            is HomeIntent.ToggleSave -> watchlist.toggle(intent.media)
        }
    }

    private fun load(refresh: Boolean) {
        if (loadJob?.isActive == true) return
        loadJob = viewModelScope.launch {
            reduce { if (refresh) copy(isRefreshing = true) else copy(isLoading = true, error = null) }
            safeCall {
                coroutineScope {
                    val hero = async { repository.trending(null).items.take(6) }
                    val trending = async { repository.trending(MediaType.MOVIE).items }
                    val popular = async { repository.popular(MediaType.MOVIE).items }
                    val popularTv = async { repository.popular(MediaType.TV).items }
                    val topRated = async { repository.topRated(MediaType.MOVIE).items }
                    val sections = listOf(
                        HomeSection(CategoryRoute(MediaType.MOVIE, "Trending Movies", CategoryList.TRENDING), trending.await()),
                        HomeSection(CategoryRoute(MediaType.MOVIE, "Popular Movies", CategoryList.POPULAR), popular.await()),
                        HomeSection(CategoryRoute(MediaType.TV, "Popular TV Shows", CategoryList.POPULAR), popularTv.await()),
                        HomeSection(CategoryRoute(MediaType.MOVIE, "Top Rated Movies", CategoryList.TOP_RATED), topRated.await()),
                    )
                    hero.await() to sections
                }
            }
                .onSuccess { (hero, sections) ->
                    reduce { copy(hero = hero, sections = sections, isLoading = false, isRefreshing = false, error = null) }
                }
                .onFailure { e ->
                    if (refresh) {
                        // Keep what's on screen; just say the refresh didn't go through.
                        reduce { copy(isRefreshing = false) }
                        postEffect(HomeEffect.ShowMessage(e.toUserMessage()))
                    } else {
                        reduce { copy(isLoading = false, error = e.toUserMessage()) }
                    }
                }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(onOpenMedia: (Media) -> Unit, onNavigate: (Any) -> Unit) {
    val store = rememberStore { HomeStore(it.mediaRepository, it.watchlist) }
    val state by store.state.collectAsStateWithLifecycle()
    val error = state.error
    val context = LocalContext.current
    val listState = rememberLazyListState()
    ScrollToTopOnTabSelect { listState.scrollToItem(0) }
    // The hero art has its own dark top edge; the scrim is only needed once rows scroll under the status bar.
    val scrolledPastHero by remember { derivedStateOf { listState.firstVisibleItemIndex > 0 } }

    CollectEffects(store.effects) { effect ->
        when (effect) {
            is HomeEffect.ShowMessage -> Toast.makeText(context, effect.message, Toast.LENGTH_SHORT).show()
        }
    }

    when {
        state.isLoading && state.hero.isEmpty() -> HomeSkeleton(heroHeight = HeroHeight)
        error != null && state.hero.isEmpty() -> MessageState(error, onRetry = { store.onIntent(HomeIntent.Retry) })
        else -> PullToRefreshBox(
            isRefreshing = state.isRefreshing,
            onRefresh = { store.onIntent(HomeIntent.Refresh) },
            modifier = Modifier.fillMaxSize(),
        ) {
            HomeContent(state, listState, onOpenMedia, onNavigate, store::onIntent)
            StatusBarScrim(visible = scrolledPastHero)
        }
    }
}

@Composable
private fun HomeContent(
    state: HomeUiState,
    listState: LazyListState,
    onOpenMedia: (Media) -> Unit,
    onNavigate: (Any) -> Unit,
    onIntent: (HomeIntent) -> Unit,
) {
    LazyColumn(Modifier.fillMaxSize(), state = listState, contentPadding = PaddingValues(bottom = BottomBarSpace)) {
        item(contentType = "hero") {
            HeroPager(
                items = state.hero,
                savedKeys = state.savedKeys,
                onOpenMedia = onOpenMedia,
                onToggleSave = { onIntent(HomeIntent.ToggleSave(it)) },
                onNavigate = onNavigate,
            )
        }
        // Same contentType lets Compose reuse a scrolled-off row's layout for the next one.
        items(state.sections, key = { it.title }, contentType = { "row" }) { section ->
            MediaRow(
                title = section.title,
                items = section.items,
                onOpen = onOpenMedia,
                onSeeAll = { onNavigate(section.category) },
            )
        }
    }
}

private val HeroHeight = 640.dp

@Composable
private fun HeroPager(
    items: List<Media>,
    savedKeys: Set<String>,
    onOpenMedia: (Media) -> Unit,
    onToggleSave: (Media) -> Unit,
    onNavigate: (Any) -> Unit,
) {
    val pagerState = rememberPagerState { items.size }
    LaunchedEffect(pagerState, items.size) {
        if (items.size > 1) {
            // Auto-advance; restarts the timer whenever the user swipes.
            snapshotFlow { pagerState.settledPage }.collectLatest { page ->
                delay(5_000)
                pagerState.animateScrollToPage((page + 1) % items.size)
            }
        }
    }

    // The artwork (with its gradient) is what the glass card blurs.
    val hazeState = rememberHazeState()

    Box(
        Modifier
            .fillMaxWidth()
            .height(HeroHeight),
    ) {
        Box(
            Modifier
                .fillMaxSize()
                .hazeSource(hazeState),
        ) {
            HorizontalPager(state = pagerState, key = { items[it].key }, modifier = Modifier.fillMaxSize()) { page ->
                AsyncImage(
                    model = TmdbImage.posterLarge(items[page].posterPath),
                    contentDescription = items[page].title,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize(),
                )
            }
            Box(
                Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(
                            0f to Color.Black.copy(alpha = 0.55f),
                            0.22f to Color.Transparent,
                            0.55f to Color.Transparent,
                            1f to AppColors.Background,
                        ),
                    ),
            )
        }
        HomeTopBar(onNavigate, Modifier.align(Alignment.TopStart))

        items.getOrNull(pagerState.currentPage)?.let { current ->
            Column(
                Modifier
                    .align(Alignment.BottomCenter)
                    .padding(horizontal = 16.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                InfoCard(
                    hazeState = hazeState,
                    title = current.title,
                    rating = current.rating,
                    meta = listOfNotNull(current.genre, current.type.label, current.year).joinToString("  •  "),
                    actionLabel = "Info",
                    onAction = { onOpenMedia(current) },
                    isSaved = current.key in savedKeys,
                    onToggleSave = { onToggleSave(current) },
                )
                PagerIndicator(count = items.size, current = pagerState.currentPage, modifier = Modifier.padding(top = 14.dp))
            }
        }
    }
}

@Composable
private fun HomeTopBar(onNavigate: (Any) -> Unit, modifier: Modifier = Modifier) {
    // Each label carries its own padding so the tappable area reaches the 48dp minimum; the
    // spacing between them stays the same as before.
    Row(
        modifier
            .fillMaxWidth()
            .statusBarsPadding()
            .padding(start = 8.dp, end = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(2.dp),
    ) {
        Text(
            "Home",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            textDecoration = TextDecoration.Underline,
            modifier = Modifier.padding(TopTabPadding),
        )
        TopTab("Movies") { onNavigate(BrowseRoute(MediaType.MOVIE, "Movie")) }
        TopTab("TV Shows") { onNavigate(BrowseRoute(MediaType.TV, "TV Shows")) }
    }
}

private val TopTabPadding = PaddingValues(horizontal = 8.dp, vertical = 13.dp)

@Composable
private fun TopTab(label: String, onClick: () -> Unit) {
    Text(
        label,
        style = MaterialTheme.typography.titleMedium,
        color = AppColors.TextPrimary.copy(alpha = 0.7f),
        modifier = Modifier
            .clip(RoundedCornerShape(50))
            .clickable(role = Role.Button, onClick = onClick)
            .padding(TopTabPadding),
    )
}

@Composable
private fun PagerIndicator(count: Int, current: Int, modifier: Modifier = Modifier) {
    Row(modifier, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        repeat(count) { index ->
            val width by animateDpAsState(if (index == current) 32.dp else 16.dp, label = "indicator")
            Box(
                Modifier
                    .width(width)
                    .height(4.dp)
                    .clip(RoundedCornerShape(50))
                    .background(if (index == current) AppColors.Primary else AppColors.TextSecondary.copy(alpha = 0.6f)),
            )
        }
    }
}
