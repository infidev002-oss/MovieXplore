package com.movies.myapplication.ui.details

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuAnchorType
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.movies.myapplication.data.model.Country
import com.movies.myapplication.data.model.DiscoverFilter
import com.movies.myapplication.data.model.TmdbImage
import com.movies.myapplication.data.model.WatchAvailability
import com.movies.myapplication.data.model.WatchOffer
import com.movies.myapplication.ui.components.ArtworkImage
import com.movies.myapplication.ui.theme.AppColors
import com.movies.myapplication.ui.theme.AppIcons
import kotlinx.coroutines.flow.first

/** The "Watch Availability" panel's state; [availability] stays null until it has been loaded. */
data class WatchPanelState(
    val isOpen: Boolean = false,
    val isLoading: Boolean = false,
    val error: String? = null,
    val countries: List<Country> = emptyList(),
    val country: String = DiscoverFilter.DEFAULT_WATCH_REGION,
    val availability: Map<String, WatchAvailability>? = null,
) {
    val selectedCountry: Country get() = countries.firstOrNull { it.code == country } ?: Country(country, country)
    val current: WatchAvailability? get() = availability?.get(country)
}

private val OfferAreaHeight = 176.dp
private val MenuItemHeight = 48.dp
private val DividerHeight = 1.dp

/** Where to stream, rent or buy the title in the chosen country, with a picker for every country. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WatchAvailabilitySheet(
    state: WatchPanelState,
    onSelectCountry: (String) -> Unit,
    onRetry: () -> Unit,
    onOpenOffer: (WatchOffer) -> Unit,
    onDismiss: () -> Unit,
) {
    val error = state.error
    val offers = state.current?.offers.orEmpty()

    ModalBottomSheet(onDismissRequest = onDismiss, containerColor = AppColors.Surface, dragHandle = null) {
        Column(
            Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .padding(top = 20.dp, bottom = 16.dp),
        ) {
            Text(
                "Watch Availability",
                style = MaterialTheme.typography.titleLarge,
                modifier = Modifier.padding(horizontal = 16.dp),
            )
            if (state.countries.isNotEmpty()) {
                CountryDropdown(
                    countries = state.countries,
                    selected = state.selectedCountry,
                    onSelect = onSelectCountry,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(start = 16.dp, end = 16.dp, top = 14.dp),
                )
            }
            Spacer(Modifier.height(14.dp))
            Box(
                Modifier
                    .fillMaxWidth()
                    .height(OfferAreaHeight),
                contentAlignment = Alignment.Center,
            ) {
                when {
                    state.isLoading || state.availability == null && error == null -> CircularProgressIndicator(color = AppColors.Primary)
                    error != null -> Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(error, style = MaterialTheme.typography.bodyMedium, color = AppColors.TextSecondary, textAlign = TextAlign.Center)
                        TextButton(onClick = onRetry) { Text("Retry", color = AppColors.Primary) }
                    }
                    offers.isEmpty() -> Text(
                        "Not available to stream, rent or buy in ${state.selectedCountry.name} yet.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = AppColors.TextSecondary,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(horizontal = 32.dp),
                    )
                    else -> LazyRow(
                        contentPadding = PaddingValues(horizontal = 16.dp),
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        modifier = Modifier.fillMaxWidth(),
                    ) {
                        items(offers, key = { "${it.type}:${it.providerId}" }) { offer ->
                            OfferCard(offer) { onOpenOffer(offer) }
                        }
                    }
                }
            }
            // TMDB's terms require crediting JustWatch wherever its watch-provider data is shown.
            Text(
                "Availability data by JustWatch",
                style = MaterialTheme.typography.bodySmall,
                color = AppColors.TextSecondary,
                modifier = Modifier.padding(start = 16.dp, end = 16.dp, top = 12.dp),
            )
        }
    }
}

/** A Material exposed dropdown: a "Country" field showing the current flag and name, opening a list of every country below it. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun CountryDropdown(countries: List<Country>, selected: Country, onSelect: (String) -> Unit, modifier: Modifier = Modifier) {
    var expanded by remember { mutableStateOf(false) }
    val scrollState = rememberScrollState()
    val rowHeightPx = with(LocalDensity.current) { (MenuItemHeight + DividerHeight).roundToPx() }

    // Open the list scrolled to the current country instead of the top of ~250 entries.
    LaunchedEffect(expanded) {
        if (!expanded) return@LaunchedEffect
        val index = countries.indexOfFirst { it.code == selected.code }
        if (index > 2) {
            snapshotFlow { scrollState.maxValue }.first { it > 0 && it != Int.MAX_VALUE }
            scrollState.scrollTo((index - 2) * rowHeightPx)
        }
    }

    ExposedDropdownMenuBox(expanded = expanded, onExpandedChange = { expanded = it }, modifier = modifier) {
        OutlinedTextField(
            value = "${selected.flag}   ${selected.name}",
            onValueChange = {},
            readOnly = true,
            singleLine = true,
            label = { Text("Country") },
            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded) },
            shape = RoundedCornerShape(12.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = AppColors.Primary,
                unfocusedBorderColor = AppColors.Outline.copy(alpha = 0.5f),
                focusedLabelColor = AppColors.Primary,
                unfocusedLabelColor = AppColors.TextSecondary,
                focusedTrailingIconColor = AppColors.Primary,
                unfocusedTrailingIconColor = AppColors.TextSecondary,
                focusedContainerColor = AppColors.SurfaceHigh,
                unfocusedContainerColor = AppColors.SurfaceHigh,
            ),
            modifier = Modifier
                .menuAnchor(ExposedDropdownMenuAnchorType.PrimaryNotEditable)
                .fillMaxWidth(),
        )
        ExposedDropdownMenu(
            expanded = expanded,
            onDismissRequest = { expanded = false },
            scrollState = scrollState,
            containerColor = AppColors.SurfaceHigh,
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.heightIn(max = 360.dp),
        ) {
            countries.forEachIndexed { index, country ->
                val isSelected = country.code == selected.code
                DropdownMenuItem(
                    text = {
                        Text(
                            "${country.flag}   ${country.name}",
                            style = MaterialTheme.typography.bodyLarge,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            color = if (isSelected) AppColors.Primary else AppColors.TextPrimary,
                        )
                    },
                    trailingIcon = if (isSelected) {
                        { Icon(AppIcons.Check, contentDescription = "Selected", tint = AppColors.Primary) }
                    } else {
                        null
                    },
                    onClick = {
                        onSelect(country.code)
                        expanded = false
                    },
                    contentPadding = ExposedDropdownMenuDefaults.ItemContentPadding,
                    modifier = Modifier
                        .height(MenuItemHeight)
                        .background(if (isSelected) AppColors.Primary.copy(alpha = 0.12f) else Color.Transparent),
                )
                if (index < countries.lastIndex) {
                    HorizontalDivider(thickness = DividerHeight, color = AppColors.Outline.copy(alpha = 0.15f))
                }
            }
        }
    }
}

@Composable
private fun OfferCard(offer: WatchOffer, onClick: () -> Unit) {
    Column(
        Modifier
            .width(110.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(AppColors.SurfaceHigh)
            .clickable(onClick = onClick)
            .padding(horizontal = 8.dp, vertical = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        ArtworkImage(
            url = TmdbImage.logo(offer.logoPath),
            contentDescription = offer.providerName,
            placeholder = AppIcons.PlayCircle,
            modifier = Modifier
                .size(58.dp)
                .clip(RoundedCornerShape(12.dp)),
        )
        Text(
            offer.providerName,
            style = MaterialTheme.typography.bodyMedium,
            textAlign = TextAlign.Center,
            minLines = 2,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.padding(top = 8.dp),
        )
        Text(
            offer.type.label,
            style = MaterialTheme.typography.labelLarge,
            color = AppColors.Primary,
            modifier = Modifier.padding(top = 4.dp),
        )
    }
}
