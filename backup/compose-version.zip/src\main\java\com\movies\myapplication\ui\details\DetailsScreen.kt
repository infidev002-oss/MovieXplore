package com.movies.myapplication.ui.details

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import coil3.compose.AsyncImage
import com.movies.myapplication.data.MediaRepository
import com.movies.myapplication.data.SettingsRepository
import com.movies.myapplication.data.WatchlistRepository
import com.movies.myapplication.data.model.Credit
import com.movies.myapplication.data.model.DiscoverFilter
import com.movies.myapplication.data.model.Episode
import com.movies.myapplication.data.model.Media
import com.movies.myapplication.data.model.MediaDetails
import com.movies.myapplication.data.model.MediaType
import com.movies.myapplication.data.model.TmdbImage
import com.movies.myapplication.data.model.Video
import com.movies.myapplication.ui.components.ArtworkImage
import com.movies.myapplication.ui.components.CircleIconButton
import com.movies.myapplication.ui.components.InfoCard
import com.movies.myapplication.ui.components.LoadingState
import com.movies.myapplication.ui.components.MediaRow
import com.movies.myapplication.ui.components.MessageState
import com.movies.myapplication.ui.components.Pill
import com.movies.myapplication.ui.components.SectionHeader
import com.movies.myapplication.ui.components.StatusBarScrim
import com.movies.myapplication.ui.formatDate
import com.movies.myapplication.ui.formatRuntime
import com.movies.myapplication.ui.mvi.MviStore
import com.movies.myapplication.ui.navigation.DetailsRoute
import com.movies.myapplication.ui.navigation.EpisodeRoute
import com.movies.myapplication.ui.navigation.PersonRoute
import com.movies.myapplication.ui.navigation.SeasonRoute
import com.movies.myapplication.ui.playOnYouTube
import com.movies.myapplication.ui.rememberStore
import com.movies.myapplication.ui.safeCall
import com.movies.myapplication.ui.theme.AppColors
import com.movies.myapplication.ui.theme.AppIcons
import com.movies.myapplication.ui.toUserMessage
import dev.chrisbanes.haze.hazeSource
import dev.chrisbanes.haze.rememberHazeState
import kotlinx.coroutines.Job
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.launch

data class DetailsUiState(
    val details: MediaDetails? = null,
    val isLoading: Boolean = true,
    val error: String? = null,
    val selectedSeason: Int? = null,
    val episodes: List<Episode> = emptyList(),
    val episodesLoading: Boolean = false,
    val savedKeys: Set<String> = emptySet(),
    val watch: WatchPanelState = WatchPanelState(),
)

sealed interface DetailsIntent {
    data object Retry : DetailsIntent
    data class SelectSeason(val number: Int) : DetailsIntent
    data class ToggleSave(val media: Media) : DetailsIntent
    data object OpenWatch : DetailsIntent
    data object CloseWatch : DetailsIntent
    data class SelectCountry(val code: String) : DetailsIntent
    data object RetryWatch : DetailsIntent
}

class DetailsStore(
    private val repository: MediaRepository,
    private val watchlist: WatchlistRepository,
    private val settings: SettingsRepository,
    private val route: DetailsRoute,
) : MviStore<DetailsUiState, DetailsIntent, Nothing>(DetailsUiState()) {

    private var episodesJob: Job? = null
    private var watchJob: Job? = null

    init {
        viewModelScope.launch { watchlist.keys.collect { keys -> reduce { copy(savedKeys = keys) } } }
        // The panel opens on the country picked last time, on any title.
        viewModelScope.launch { settings.watchCountry.collect { code -> reduce { copy(watch = watch.copy(country = code)) } } }
        load()
    }

    override fun onIntent(intent: DetailsIntent) {
        when (intent) {
            DetailsIntent.Retry -> load()
            is DetailsIntent.SelectSeason -> selectSeason(intent.number)
            is DetailsIntent.ToggleSave -> watchlist.toggle(intent.media)
            DetailsIntent.OpenWatch -> {
                reduce { copy(watch = watch.copy(isOpen = true)) }
                if (currentState.watch.availability == null) loadWatch()
            }
            DetailsIntent.CloseWatch -> reduce { copy(watch = watch.copy(isOpen = false)) }
            is DetailsIntent.SelectCountry -> {
                reduce { copy(watch = watch.copy(country = intent.code)) }
                settings.setWatchCountry(intent.code)
            }
            DetailsIntent.RetryWatch -> loadWatch()
        }
    }

    /** One call returns every country's offers, so switching country afterwards needs no request. */
    private fun loadWatch() {
        if (watchJob?.isActive == true) return
        watchJob = viewModelScope.launch {
            reduce { copy(watch = watch.copy(isLoading = true, error = null)) }
            safeCall {
                coroutineScope {
                    val countries = async { repository.countries() }
                    val availability = async { repository.watchAvailability(route.type, route.id) }
                    countries.await() to availability.await()
                }
            }
                .onSuccess { (countries, availability) ->
                    reduce {
                        val country = watch.country.takeIf { code -> countries.any { it.code == code } }
                            ?: DiscoverFilter.DEFAULT_WATCH_REGION
                        copy(watch = watch.copy(isLoading = false, countries = countries, availability = availability, country = country))
                    }
                }
                .onFailure { e -> reduce { copy(watch = watch.copy(isLoading = false, error = e.toUserMessage())) } }
        }
    }

    private fun load() {
        viewModelScope.launch {
            reduce { copy(isLoading = true, error = null) }
            safeCall { repository.details(route.type, route.id) }
                .onSuccess { details ->
                    reduce { copy(details = details, isLoading = false) }
                    details.seasons.firstOrNull()?.let { selectSeason(it.number) }
                }
                .onFailure { e -> reduce { copy(isLoading = false, error = e.toUserMessage()) } }
        }
    }

    private fun selectSeason(number: Int) {
        episodesJob?.cancel()
        reduce { copy(selectedSeason = number, episodes = emptyList(), episodesLoading = true) }
        episodesJob = viewModelScope.launch {
            val episodes = safeCall { repository.episodes(route.id, number) }.getOrDefault(emptyList())
            reduce { copy(episodes = episodes, episodesLoading = false) }
        }
    }
}

@Composable
fun DetailsScreen(route: DetailsRoute, onBack: () -> Unit, onOpenMedia: (Media) -> Unit, onNavigate: (Any) -> Unit) {
    val store = rememberStore { DetailsStore(it.mediaRepository, it.watchlist, it.settings, route) }
    val state by store.state.collectAsStateWithLifecycle()
    val details = state.details
    val error = state.error

    Box(Modifier.fillMaxSize()) {
        when {
            details != null -> DetailsContent(state, details, store::onIntent, onOpenMedia, onNavigate)
            state.isLoading -> LoadingState()
            error != null -> MessageState(error, onRetry = { store.onIntent(DetailsIntent.Retry) })
        }
        CircleIconButton(
            AppIcons.Back,
            contentDescription = "Back",
            onClick = onBack,
            size = 42.dp,
            modifier = Modifier
                .statusBarsPadding()
                .padding(12.dp),
        )
    }
}

@Composable
private fun DetailsContent(
    state: DetailsUiState,
    details: MediaDetails,
    onIntent: (DetailsIntent) -> Unit,
    onOpenMedia: (Media) -> Unit,
    onNavigate: (Any) -> Unit,
) {
    val media = details.media
    val uriHandler = LocalUriHandler.current
    // openUri throws if no app can handle the link; a missing browser must not crash the app.
    val openLink: (String) -> Unit = { url -> runCatching { uriHandler.openUri(url) } }

    val listState = rememberLazyListState()
    val scrolledPastArt by remember { derivedStateOf { listState.firstVisibleItemIndex > 0 } }

    LazyColumn(
        state = listState,
        contentPadding = PaddingValues(bottom = 32.dp),
        modifier = Modifier
            .fillMaxSize()
            .navigationBarsPadding(),
    ) {
        item {
            val hazeState = rememberHazeState()
            Box {
                Box(Modifier.hazeSource(hazeState)) {
                    ArtworkImage(
                        url = TmdbImage.posterLarge(media.posterPath) ?: TmdbImage.backdrop(media.backdropPath),
                        contentDescription = media.title,
                        placeholder = AppIcons.Movie,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(560.dp),
                    )
                    Box(
                        Modifier
                            .fillMaxWidth()
                            .height(560.dp)
                            .background(Brush.verticalGradient(0.5f to Color.Transparent, 1f to AppColors.Background)),
                    )
                }
                InfoCard(
                    hazeState = hazeState,
                    title = media.title,
                    rating = media.rating,
                    meta = listOfNotNull(details.genres.firstOrNull(), details.country, media.year).joinToString("  •  "),
                    overview = media.overview,
                    actionLabel = "Watch Availability",
                    onAction = { onIntent(DetailsIntent.OpenWatch) },
                    isSaved = media.key in state.savedKeys,
                    onToggleSave = { onIntent(DetailsIntent.ToggleSave(media)) },
                    modifier = Modifier.padding(start = 16.dp, end = 16.dp, top = 400.dp),
                )
            }
        }

        item { TrailersSection(details.videos) }

        if (media.type == MediaType.TV && details.seasons.isNotEmpty()) {
            item {
                val selected = state.selectedSeason ?: details.seasons.first().number
                SectionHeader("Choose Season", onSeeAll = { onNavigate(SeasonRoute(media.id, media.title, selected, media.backdropPath)) })
                LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(details.seasons, key = { it.number }) { season ->
                        Pill(season.name.ifBlank { "Season ${season.number}" }, selected = season.number == selected, onClick = { onIntent(DetailsIntent.SelectSeason(season.number)) })
                    }
                }
                if (state.episodesLoading) {
                    Box(
                        Modifier
                            .fillMaxWidth()
                            .height(150.dp),
                        contentAlignment = Alignment.Center,
                    ) { CircularProgressIndicator(color = AppColors.Primary) }
                } else {
                    LazyRow(
                        contentPadding = PaddingValues(16.dp),
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                    ) {
                        items(state.episodes, key = { it.id }) { episode ->
                            EpisodeCard(episode, media.backdropPath) {
                                onNavigate(EpisodeRoute(media.id, media.title, selected, episode.number, media.backdropPath))
                            }
                        }
                    }
                }
            }
        }

        item { CreditsSection("Actors and Creators", details.credits) { onNavigate(PersonRoute(it)) } }

        item {
            MediaRow(
                title = "Similar",
                items = details.similar,
                onOpen = onOpenMedia,
            )
        }
    }
    // Drawn before DetailsScreen's back button, so the button stays on top of it.
    StatusBarScrim(visible = scrolledPastArt)

    if (state.watch.isOpen) {
        WatchAvailabilitySheet(
            state = state.watch,
            onSelectCountry = { onIntent(DetailsIntent.SelectCountry(it)) },
            onRetry = { onIntent(DetailsIntent.RetryWatch) },
            // TMDB's per-country watch page links out to each service; fall back to the title's general watch page.
            onOpenOffer = { openLink(state.watch.current?.link ?: details.watchUrl) },
            onDismiss = { onIntent(DetailsIntent.CloseWatch) },
        )
    }
}

@Composable
fun TrailersSection(videos: List<Video>) {
    if (videos.isEmpty()) return
    val context = LocalContext.current
    SectionHeader("Trailers & Teasers")
    LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        items(videos, key = { it.key }) { video -> VideoCard(video) { context.playOnYouTube(video) } }
    }
}

@Composable
fun CreditsSection(title: String, credits: List<Credit>, onOpenPerson: (Int) -> Unit) {
    if (credits.isEmpty()) return
    SectionHeader(title)
    LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
        items(credits, key = { it.id }) { credit -> CreditItem(credit) { onOpenPerson(credit.id) } }
    }
}

@Composable
private fun VideoCard(video: Video, onClick: () -> Unit) {
    Column(
        Modifier
            .width(220.dp)
            .clickable(onClick = onClick),
    ) {
        Thumbnail(video.thumbnailUrl, video.name)
        Text(video.name, style = MaterialTheme.typography.bodyLarge, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 6.dp))
        Text(video.type, style = MaterialTheme.typography.bodyMedium, color = AppColors.TextSecondary)
    }
}

@Composable
private fun EpisodeCard(episode: Episode, showBackdropPath: String?, onClick: () -> Unit) {
    Column(
        Modifier
            .width(170.dp)
            .clickable(onClick = onClick),
    ) {
        Thumbnail(episode.stillUrl(showBackdropPath), episode.name)
        Text(
            "${episode.number}. ${episode.name}",
            style = MaterialTheme.typography.bodyMedium,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.padding(top = 6.dp),
        )
        Text(
            listOfNotNull(formatRuntime(episode.runtime), formatDate(episode.airDate)).joinToString(" • "),
            style = MaterialTheme.typography.bodySmall,
            color = AppColors.TextSecondary,
        )
    }
}

/** The episode's own still, or the show's backdrop when TMDB has none yet (common for unaired episodes). */
fun Episode.stillUrl(showBackdropPath: String?): String? =
    TmdbImage.still(stillPath) ?: TmdbImage.backdrop(showBackdropPath)

@Composable
fun Thumbnail(url: String?, contentDescription: String, modifier: Modifier = Modifier) {
    Box(
        modifier
            .fillMaxWidth()
            .aspectRatio(16f / 9f)
            .clip(RoundedCornerShape(10.dp))
            .background(AppColors.SurfaceHigh),
        contentAlignment = Alignment.Center,
    ) {
        AsyncImage(
            model = url,
            contentDescription = contentDescription,
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize(),
        )
        Icon(AppIcons.PlayCircle, contentDescription = null, tint = Color.White, modifier = Modifier.size(36.dp))
    }
}

@Composable
private fun CreditItem(credit: Credit, onClick: () -> Unit) {
    Column(
        Modifier
            .width(90.dp)
            .clickable(onClick = onClick),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        ArtworkImage(
            url = TmdbImage.profile(credit.profilePath),
            contentDescription = credit.name,
            placeholder = AppIcons.Person,
            modifier = Modifier
                .size(80.dp)
                .clip(CircleShape),
        )
        Text(credit.name, style = MaterialTheme.typography.bodyMedium, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 6.dp))
        Text(credit.role, style = MaterialTheme.typography.bodySmall, color = AppColors.TextSecondary)
    }
}
