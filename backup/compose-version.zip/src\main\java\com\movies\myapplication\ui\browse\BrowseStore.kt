package com.movies.myapplication.ui.browse

import androidx.lifecycle.viewModelScope
import com.movies.myapplication.data.MediaRepository
import com.movies.myapplication.data.model.DiscoverFilter
import com.movies.myapplication.data.model.Genre
import com.movies.myapplication.data.model.Media
import com.movies.myapplication.data.model.MediaType
import com.movies.myapplication.data.model.PageResult
import com.movies.myapplication.data.model.Provider
import com.movies.myapplication.ui.components.PagedContent
import com.movies.myapplication.ui.mvi.MviStore
import com.movies.myapplication.ui.safeCall
import com.movies.myapplication.ui.toUserMessage
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.debounce
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.onStart
import kotlinx.coroutines.launch

data class BrowseUiState(
    val query: String = "",
    val filter: DiscoverFilter = DiscoverFilter(),
    val genres: List<Genre> = emptyList(),
    val providers: List<Provider> = emptyList(),
    val showFilters: Boolean = false,
    override val items: List<Media> = emptyList(),
    override val isLoading: Boolean = true,
    override val isLoadingMore: Boolean = false,
    override val error: String? = null,
    /** The trimmed query the current [items] were loaded for. */
    val loadedQuery: String = "",
    val page: Int = 0,
    val hasMore: Boolean = false,
) : PagedContent

sealed interface BrowseIntent {
    data class QueryChanged(val query: String) : BrowseIntent
    data object OpenFilters : BrowseIntent
    data object CloseFilters : BrowseIntent
    data class ApplyFilter(val filter: DiscoverFilter) : BrowseIntent
    data class RegionChanged(val region: String?) : BrowseIntent
    data object LoadMore : BrowseIntent
    data object Retry : BrowseIntent
}

/**
 * Paged results for one media type: discover when the query is empty, text search otherwise.
 * [loadGenres] fetches the genre list for screens that show genre chips or the filter panel.
 */
@OptIn(FlowPreview::class)
class BrowseStore(
    private val repository: MediaRepository,
    private val type: MediaType,
    initialFilter: DiscoverFilter,
    loadGenres: Boolean = false,
) : MviStore<BrowseUiState, BrowseIntent, Nothing>(BrowseUiState(filter = initialFilter)) {

    private val retries = MutableSharedFlow<Unit>(extraBufferCapacity = 1)
    private var loadMoreJob: Job? = null
    private var providersJob: Job? = null

    init {
        // The first page reloads whenever the (debounced) query or the filter in the state changes, or on retry.
        viewModelScope.launch {
            val query = state
                .map { it.query }
                .distinctUntilChanged()
                .debounce { if (it.isBlank()) 0L else 400L }
                .map { it.trim() }
                .distinctUntilChanged()
            val filter = state.map { it.filter }.distinctUntilChanged()
            combine(query, filter, retries.onStart { emit(Unit) }) { q, f, _ -> q to f }
                .collectLatest { (q, f) -> loadFirstPage(q, f) }
        }
        if (loadGenres) {
            viewModelScope.launch {
                val genres = safeCall { repository.genres(type) }.getOrDefault(emptyList())
                reduce { copy(genres = genres) }
            }
        }
    }

    override fun onIntent(intent: BrowseIntent) {
        when (intent) {
            is BrowseIntent.QueryChanged -> reduce { copy(query = intent.query) }
            BrowseIntent.OpenFilters -> reduce { copy(showFilters = true) }
            BrowseIntent.CloseFilters -> reduce { copy(showFilters = false) }
            is BrowseIntent.ApplyFilter -> reduce { copy(filter = intent.filter, showFilters = false) }
            is BrowseIntent.RegionChanged -> loadProviders(intent.region)
            BrowseIntent.LoadMore -> loadMore()
            BrowseIntent.Retry -> retries.tryEmit(Unit)
        }
    }

    private fun loadProviders(region: String?) {
        providersJob?.cancel()
        providersJob = viewModelScope.launch {
            val providers = safeCall {
                repository.providers(type, region ?: DiscoverFilter.DEFAULT_WATCH_REGION)
            }.getOrDefault(emptyList())
            reduce { copy(providers = providers) }
        }
    }

    private fun loadMore() {
        val current = currentState
        if (!current.hasMore || current.isLoading || loadMoreJob?.isActive == true) return
        loadMoreJob = viewModelScope.launch {
            reduce { copy(isLoadingMore = true) }
            safeCall { fetch(current.loadedQuery, current.filter, current.page + 1) }
                .onSuccess { result ->
                    reduce {
                        copy(
                            items = (items + result.items).distinctBy { it.key },
                            page = result.page,
                            hasMore = result.hasMore,
                            isLoadingMore = false,
                        )
                    }
                }
                .onFailure { reduce { copy(isLoadingMore = false) } }
        }
    }

    private suspend fun loadFirstPage(q: String, f: DiscoverFilter) {
        loadMoreJob?.cancel()
        reduce { copy(loadedQuery = q, isLoading = true, isLoadingMore = false, error = null) }
        safeCall { fetch(q, f, 1) }
            .onSuccess { result ->
                reduce {
                    copy(
                        items = result.items.distinctBy { it.key },
                        page = result.page,
                        hasMore = result.hasMore,
                        isLoading = false,
                    )
                }
            }
            .onFailure { e ->
                reduce { copy(items = emptyList(), hasMore = false, isLoading = false, error = e.toUserMessage()) }
            }
    }

    private suspend fun fetch(q: String, f: DiscoverFilter, page: Int): PageResult =
        if (q.isEmpty()) repository.discover(type, f, page) else repository.search(type, q, f, page)
}
