package com.movies.myapplication.data.remote

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
data class PageDto<T>(
    val page: Int = 1,
    val results: List<T> = emptyList(),
    @SerialName("total_pages") val totalPages: Int = 1,
)

@Serializable
data class MediaDto(
    val id: Int,
    val title: String? = null,
    val name: String? = null,
    @SerialName("poster_path") val posterPath: String? = null,
    @SerialName("backdrop_path") val backdropPath: String? = null,
    val overview: String? = null,
    @SerialName("release_date") val releaseDate: String? = null,
    @SerialName("first_air_date") val firstAirDate: String? = null,
    @SerialName("vote_average") val voteAverage: Double = 0.0,
    @SerialName("genre_ids") val genreIds: List<Int> = emptyList(),
    @SerialName("media_type") val mediaType: String? = null,
    @SerialName("original_language") val originalLanguage: String? = null,
    val popularity: Double = 0.0,
)

@Serializable
data class GenreDto(val id: Int, val name: String)

@Serializable
data class GenreListDto(val genres: List<GenreDto> = emptyList())

@Serializable
data class DetailsDto(
    val id: Int,
    val title: String? = null,
    val name: String? = null,
    @SerialName("poster_path") val posterPath: String? = null,
    @SerialName("backdrop_path") val backdropPath: String? = null,
    val overview: String? = null,
    @SerialName("release_date") val releaseDate: String? = null,
    @SerialName("first_air_date") val firstAirDate: String? = null,
    @SerialName("vote_average") val voteAverage: Double = 0.0,
    val genres: List<GenreDto> = emptyList(),
    @SerialName("origin_country") val originCountry: List<String> = emptyList(),
    @SerialName("production_countries") val productionCountries: List<CountryDto> = emptyList(),
    val seasons: List<SeasonSummaryDto> = emptyList(),
    @SerialName("created_by") val createdBy: List<PersonRefDto> = emptyList(),
    val videos: VideoListDto? = null,
    val credits: CreditsDto? = null,
    val similar: PageDto<MediaDto>? = null,
)

@Serializable
data class CountryDto(@SerialName("iso_3166_1") val code: String)

@Serializable
data class SeasonSummaryDto(
    @SerialName("season_number") val number: Int,
    val name: String = "",
    @SerialName("episode_count") val episodeCount: Int = 0,
)

@Serializable
data class PersonRefDto(
    val id: Int,
    val name: String,
    @SerialName("profile_path") val profilePath: String? = null,
    val gender: Int = 0,
    val character: String? = null,
    val job: String? = null,
)

@Serializable
data class VideoListDto(val results: List<VideoDto> = emptyList())

@Serializable
data class VideoDto(
    val key: String,
    val name: String = "",
    val site: String = "",
    val type: String = "",
)

@Serializable
data class CreditsDto(
    val cast: List<PersonRefDto> = emptyList(),
    val crew: List<PersonRefDto> = emptyList(),
)

@Serializable
data class SeasonDto(val episodes: List<EpisodeDto> = emptyList())

@Serializable
data class EpisodeDto(
    val id: Int,
    val name: String = "",
    @SerialName("episode_number") val number: Int = 0,
    @SerialName("still_path") val stillPath: String? = null,
    val runtime: Int? = null,
    @SerialName("air_date") val airDate: String? = null,
)

@Serializable
data class EpisodeDetailsDto(
    val name: String = "",
    val overview: String? = null,
    @SerialName("season_number") val seasonNumber: Int = 0,
    @SerialName("episode_number") val number: Int = 0,
    @SerialName("still_path") val stillPath: String? = null,
    @SerialName("air_date") val airDate: String? = null,
    val runtime: Int? = null,
    @SerialName("vote_average") val voteAverage: Double = 0.0,
    @SerialName("guest_stars") val guestStars: List<PersonRefDto> = emptyList(),
    val crew: List<PersonRefDto> = emptyList(),
    val videos: VideoListDto? = null,
)

@Serializable
data class PersonDto(
    val id: Int,
    val name: String,
    val biography: String? = null,
    val birthday: String? = null,
    @SerialName("place_of_birth") val placeOfBirth: String? = null,
    @SerialName("profile_path") val profilePath: String? = null,
    @SerialName("combined_credits") val combinedCredits: CombinedCreditsDto? = null,
)

@Serializable
data class CombinedCreditsDto(val cast: List<MediaDto> = emptyList())

@Serializable
data class ProviderListDto(val results: List<ProviderDto> = emptyList())

@Serializable
data class ProviderDto(
    @SerialName("provider_id") val id: Int,
    @SerialName("provider_name") val name: String,
    @SerialName("display_priority") val priority: Int = Int.MAX_VALUE,
    @SerialName("logo_path") val logoPath: String? = null,
)

/** Keyed by ISO 3166-1 country code. */
@Serializable
data class WatchProvidersDto(val results: Map<String, CountryOffersDto> = emptyMap())

@Serializable
data class CountryOffersDto(
    val link: String? = null,
    val flatrate: List<ProviderDto> = emptyList(),
    val free: List<ProviderDto> = emptyList(),
    val ads: List<ProviderDto> = emptyList(),
    val rent: List<ProviderDto> = emptyList(),
    val buy: List<ProviderDto> = emptyList(),
)

@Serializable
data class WatchRegionListDto(val results: List<WatchRegionDto> = emptyList())

@Serializable
data class WatchRegionDto(
    @SerialName("iso_3166_1") val code: String,
    @SerialName("english_name") val englishName: String = "",
)
