package com.movies.myapplication.ui.browse

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import com.movies.myapplication.data.model.DiscoverFilter
import com.movies.myapplication.data.model.FilterOptions
import com.movies.myapplication.data.model.Genre
import com.movies.myapplication.data.model.Provider
import com.movies.myapplication.data.model.SortOption
import com.movies.myapplication.ui.components.PrimaryButton
import com.movies.myapplication.ui.theme.AppColors
import com.movies.myapplication.ui.theme.AppIcons

private enum class FilterField(val label: String) {
    YEAR("Year"), GENRE("Genre"), SORT("Sort By"), REGION("Region"), LANGUAGE("Language"), CHANNEL("Channels")
}

private class FilterOption(val label: String, val selected: Boolean, val apply: (DiscoverFilter) -> DiscoverFilter)

private val PanelColor = Color(0xFF0B1219)
private val RowColor = Color(0xFF151E28)

/** Right-side filter drawer. Edits a draft and only reports it back on Apply. */
@Composable
fun FilterPanel(
    visible: Boolean,
    filter: DiscoverFilter,
    genres: List<Genre>,
    providers: List<Provider>,
    isSearching: Boolean,
    onRegionChange: (String?) -> Unit,
    onApply: (DiscoverFilter) -> Unit,
    onDismiss: () -> Unit,
) {
    var draft by remember(visible, filter) { mutableStateOf(filter) }
    var editing by remember(visible) { mutableStateOf<FilterField?>(null) }

    LaunchedEffect(visible, draft.region) {
        if (visible) onRegionChange(draft.region)
    }
    BackHandler(enabled = visible) {
        if (editing != null) editing = null else onDismiss()
    }

    Box(Modifier.fillMaxSize()) {
        AnimatedVisibility(visible, enter = fadeIn(), exit = fadeOut()) {
            Box(
                Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.55f))
                    .clickable(interactionSource = null, indication = null, onClick = onDismiss),
            )
        }
        AnimatedVisibility(
            visible = visible,
            enter = slideInHorizontally { it },
            exit = slideOutHorizontally { it },
            modifier = Modifier.align(Alignment.CenterEnd),
        ) {
            Column(
                Modifier
                    .fillMaxHeight()
                    .fillMaxWidth(0.84f)
                    .background(PanelColor)
                    // Swallow taps so they don't reach the scrim behind the panel.
                    .clickable(interactionSource = null, indication = null) {}
                    .statusBarsPadding()
                    .navigationBarsPadding(),
            ) {
                val field = editing
                if (field == null) {
                    FilterSummary(
                        draft = draft,
                        genres = genres,
                        providers = providers,
                        isSearching = isSearching,
                        onEdit = { editing = it },
                        onReset = { draft = DiscoverFilter() },
                        onApply = { onApply(draft) },
                        onClose = onDismiss,
                    )
                } else {
                    OptionList(
                        title = field.label,
                        options = optionsFor(field, draft, genres, providers),
                        onBack = { editing = null },
                        onSelect = { option ->
                            draft = option.apply(draft)
                            editing = null
                        },
                    )
                }
            }
        }
    }
}

@Composable
private fun ColumnScope.FilterSummary(
    draft: DiscoverFilter,
    genres: List<Genre>,
    providers: List<Provider>,
    isSearching: Boolean,
    onEdit: (FilterField) -> Unit,
    onReset: () -> Unit,
    onApply: () -> Unit,
    onClose: () -> Unit,
) {
    PanelHeader("Filter", AppIcons.Close, "Close filters", onClose, iconAtEnd = true)
    Column(
        Modifier
            .weight(1f)
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp),
    ) {
        if (isSearching) {
            Text(
                "While searching, only Year, Genre and Language apply.",
                style = MaterialTheme.typography.bodySmall,
                color = AppColors.TextSecondary,
                modifier = Modifier.padding(top = 12.dp),
            )
        }
        FilterField.entries.forEach { field ->
            Text(field.label, style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(top = 20.dp, bottom = 10.dp))
            Row(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(10.dp))
                    .background(RowColor)
                    .clickable { onEdit(field) }
                    .padding(horizontal = 16.dp, vertical = 16.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(valueLabel(field, draft, genres, providers), style = MaterialTheme.typography.bodyLarge, modifier = Modifier.weight(1f))
                Icon(AppIcons.ChevronRight, contentDescription = null)
            }
        }
        Spacer(Modifier.height(24.dp))
    }
    Row(
        Modifier.padding(16.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        PrimaryButton("Apply", onApply, Modifier.weight(1f))
        Spacer(Modifier.width(16.dp))
        Icon(
            AppIcons.Refresh,
            contentDescription = "Reset filters",
            modifier = Modifier
                .clip(CircleShape)
                .clickable(onClick = onReset)
                .padding(10.dp)
                .size(28.dp),
        )
    }
}

@Composable
private fun OptionList(title: String, options: List<FilterOption>, onBack: () -> Unit, onSelect: (FilterOption) -> Unit) {
    PanelHeader(title, AppIcons.Back, "Back", onBack, iconAtEnd = false)
    LazyColumn(Modifier.fillMaxSize()) {
        items(options) { option ->
            Row(
                Modifier
                    .fillMaxWidth()
                    .clickable { onSelect(option) }
                    .padding(horizontal = 24.dp, vertical = 16.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(
                    option.label,
                    style = MaterialTheme.typography.bodyLarge,
                    color = if (option.selected) AppColors.Primary else AppColors.TextPrimary,
                    modifier = Modifier.weight(1f),
                )
                if (option.selected) Icon(AppIcons.Check, contentDescription = "Selected", tint = AppColors.Primary)
            }
        }
    }
}

@Composable
private fun PanelHeader(title: String, icon: ImageVector, iconDescription: String, onIconClick: () -> Unit, iconAtEnd: Boolean) {
    Row(
        Modifier
            .fillMaxWidth()
            .background(RowColor)
            .padding(horizontal = 12.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        val button = @Composable {
            Icon(
                icon,
                contentDescription = iconDescription,
                modifier = Modifier
                    .clip(CircleShape)
                    .clickable(onClick = onIconClick)
                    .padding(8.dp),
            )
        }
        if (!iconAtEnd) button()
        Text(
            title,
            style = MaterialTheme.typography.headlineSmall,
            modifier = Modifier
                .weight(1f)
                .padding(horizontal = 12.dp),
        )
        if (iconAtEnd) button()
    }
}

private fun valueLabel(field: FilterField, draft: DiscoverFilter, genres: List<Genre>, providers: List<Provider>): String =
    when (field) {
        FilterField.YEAR -> draft.year?.toString() ?: "Default"
        FilterField.GENRE -> when (draft.genreIds.size) {
            0 -> "All Genres"
            1 -> genres.firstOrNull { it.id in draft.genreIds }?.name ?: "1 genre"
            else -> "${draft.genreIds.size} genres"
        }
        FilterField.SORT -> draft.sort.label
        FilterField.REGION -> FilterOptions.regionName(draft.region) ?: "Global"
        FilterField.LANGUAGE -> FilterOptions.languageName(draft.language) ?: "All Languages"
        FilterField.CHANNEL -> draft.providerId?.let { id -> providers.firstOrNull { it.id == id }?.name ?: "Selected channel" }
            ?: "All Channels"
    }

private fun optionsFor(field: FilterField, draft: DiscoverFilter, genres: List<Genre>, providers: List<Provider>): List<FilterOption> =
    when (field) {
        FilterField.YEAR -> listOf(FilterOption("Default", draft.year == null) { it.copy(year = null) }) +
            FilterOptions.years.map { year -> FilterOption(year.toString(), draft.year == year) { it.copy(year = year) } }
        FilterField.GENRE -> listOf(FilterOption("All Genres", draft.genreIds.isEmpty()) { it.copy(genreIds = emptySet()) }) +
            genres.map { genre ->
                FilterOption(genre.name, draft.genreIds == setOf(genre.id)) { it.copy(genreIds = setOf(genre.id), matchAnyGenre = false) }
            }
        FilterField.SORT -> SortOption.entries.map { sort -> FilterOption(sort.label, draft.sort == sort) { it.copy(sort = sort) } }
        FilterField.REGION -> listOf(FilterOption("Global", draft.region == null) { it.copy(region = null) }) +
            FilterOptions.regions.map { (code, name) -> FilterOption(name, draft.region == code) { it.copy(region = code) } }
        FilterField.LANGUAGE -> listOf(FilterOption("All Languages", draft.language == null) { it.copy(language = null) }) +
            FilterOptions.languages.map { (code, name) -> FilterOption(name, draft.language == code) { it.copy(language = code) } }
        FilterField.CHANNEL -> listOf(FilterOption("All Channels", draft.providerId == null) { it.copy(providerId = null) }) +
            providers.map { provider -> FilterOption(provider.name, draft.providerId == provider.id) { it.copy(providerId = provider.id) } }
    }
