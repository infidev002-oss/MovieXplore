package com.movies.myapplication.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.LazyGridState
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import coil3.compose.AsyncImage
import com.movies.myapplication.data.model.Media
import com.movies.myapplication.data.model.TmdbImage
import com.movies.myapplication.ui.theme.AppColors
import com.movies.myapplication.ui.theme.AppIcons
import dev.chrisbanes.haze.HazeState
import dev.chrisbanes.haze.hazeSource
import dev.chrisbanes.haze.rememberHazeState
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.filter
import kotlinx.coroutines.launch
import java.util.Locale

/** The floating nav bar's height above the system navigation bar: 52dp buttons, 2×10dp padding, 12dp margin. */
val FloatingNavBarHeight = 84.dp

/**
 * Space reserved at the bottom of tab screens so content clears the floating nav bar, plus a small gap.
 * It includes the system navigation bar under it, which is far taller with 3-button navigation than
 * with gestures, so a fixed value would leave content hidden on 3-button phones.
 */
val BottomBarSpace: Dp
    @Composable get() = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding() + FloatingNavBarHeight + 16.dp

/** Poster with title, year/genre and rating. Pass a null [onToggleSave] to hide the save button. */
@Composable
fun PosterCard(
    media: Media,
    isSaved: Boolean,
    onClick: () -> Unit,
    onToggleSave: (() -> Unit)?,
    modifier: Modifier = Modifier,
) {
    // The poster is what this card's save button blurs.
    val hazeState = rememberHazeState()
    Column(modifier.clickable(onClick = onClick)) {
        Box(
            Modifier
                .fillMaxWidth()
                .aspectRatio(2f / 3f)
                .clip(RoundedCornerShape(12.dp))
                .background(AppColors.SurfaceHigh),
        ) {
            ArtworkImage(
                url = TmdbImage.poster(media.posterPath),
                contentDescription = media.title,
                placeholder = AppIcons.Movie,
                modifier = Modifier
                    .fillMaxSize()
                    // Without a save button there's nothing to blur, so skip the extra layer.
                    .then(if (onToggleSave != null) Modifier.hazeSource(hazeState) else Modifier),
            )
            if (onToggleSave != null) {
                BookmarkButton(
                    isSaved = isSaved,
                    onClick = onToggleSave,
                    hazeState = hazeState,
                    size = 34.dp,
                    modifier = Modifier.align(Alignment.TopEnd).padding(6.dp),
                )
            }
        }
        Spacer(Modifier.height(6.dp))
        Text(media.title, style = MaterialTheme.typography.bodyLarge, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Text(
            listOfNotNull(media.year, media.genre).joinToString(" • "),
            style = MaterialTheme.typography.bodyMedium,
            color = AppColors.TextSecondary,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
        Rating(media.rating, Modifier.padding(top = 4.dp))
    }
}

@Composable
fun PosterImage(path: String?, contentDescription: String, onClick: () -> Unit, modifier: Modifier = Modifier) {
    ArtworkImage(
        url = TmdbImage.poster(path),
        contentDescription = contentDescription,
        placeholder = AppIcons.Movie,
        modifier = modifier
            .aspectRatio(2f / 3f)
            .clip(RoundedCornerShape(10.dp))
            .clickable(onClick = onClick),
    )
}

private const val ImageRetries = 2

/**
 * A TMDB image drawn over a placeholder icon. The icon stays visible while loading, when TMDB
 * has no image for the item ([url] is null), or when the download fails. A failed download is
 * retried a couple of times, so a brief network drop doesn't leave the card blank.
 */
@Composable
fun ArtworkImage(url: String?, contentDescription: String?, placeholder: ImageVector, modifier: Modifier = Modifier) {
    var attempt by remember(url) { mutableIntStateOf(0) }
    val scope = rememberCoroutineScope()
    Box(modifier.background(AppColors.SurfaceHigh), contentAlignment = Alignment.Center) {
        Icon(
            placeholder,
            contentDescription = null,
            tint = AppColors.TextSecondary.copy(alpha = 0.6f),
            modifier = Modifier.fillMaxSize(0.35f),
        )
        if (url != null) {
            // A new key starts a fresh request; failed requests aren't cached, so this really re-downloads.
            key(attempt) {
                AsyncImage(
                    model = url,
                    contentDescription = contentDescription,
                    contentScale = ContentScale.Crop,
                    onError = {
                        if (attempt < ImageRetries) {
                            scope.launch {
                                delay(1_000L * (attempt + 1))
                                attempt++
                            }
                        }
                    },
                    modifier = Modifier.fillMaxSize(),
                )
            }
        }
    }
}

/**
 * Darkens the strip behind the transparent status bar once content has scrolled under it, so the
 * clock and status icons stay readable. Place it last (on top) in a screen's root Box.
 */
@Composable
fun StatusBarScrim(visible: Boolean, modifier: Modifier = Modifier) {
    val alpha by animateFloatAsState(if (visible) 1f else 0f, label = "statusBarScrim")
    Box(
        modifier
            .fillMaxWidth()
            .graphicsLayer { this.alpha = alpha }
            .background(Brush.verticalGradient(listOf(AppColors.Background.copy(alpha = 0.92f), Color.Transparent)))
            .statusBarsPadding()
            .padding(bottom = 16.dp),
    )
}

/** Frosted-glass save button that blurs the artwork registered with [hazeState] behind it. */
@Composable
fun BookmarkButton(
    isSaved: Boolean,
    onClick: () -> Unit,
    hazeState: HazeState,
    modifier: Modifier = Modifier,
    size: Dp = 44.dp,
) {
    val haptics = LocalHapticFeedback.current
    Box(
        modifier
            .size(size)
            .glass(hazeState, CircleShape, GlassTone.Button)
            .clickable {
                haptics.performHapticFeedback(if (isSaved) HapticFeedbackType.ToggleOff else HapticFeedbackType.ToggleOn)
                onClick()
            },
        contentAlignment = Alignment.Center,
    ) {
        Icon(
            imageVector = if (isSaved) AppIcons.BookmarkFilled else AppIcons.Bookmark,
            contentDescription = if (isSaved) "Remove from watchlist" else "Add to watchlist",
            tint = Color.White,
            modifier = Modifier.size(size * 0.55f),
        )
    }
}

@Composable
fun Rating(value: Double, modifier: Modifier = Modifier) {
    Row(modifier, verticalAlignment = Alignment.CenterVertically) {
        Icon(AppIcons.Star, contentDescription = null, tint = AppColors.Star, modifier = Modifier.size(16.dp))
        Spacer(Modifier.width(4.dp))
        Text(String.format(Locale.US, "%.1f", value), style = MaterialTheme.typography.bodyMedium)
    }
}

@Composable
fun SectionHeader(title: String, modifier: Modifier = Modifier, onSeeAll: (() -> Unit)? = null) {
    // With "see all", the whole header is the tap target rather than just the small arrow.
    Row(
        modifier
            .fillMaxWidth()
            .then(if (onSeeAll != null) Modifier.clickable(onClickLabel = "See all $title", onClick = onSeeAll) else Modifier)
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(title, style = MaterialTheme.typography.titleLarge, modifier = Modifier.weight(1f))
        if (onSeeAll != null) {
            Icon(AppIcons.ChevronRight, contentDescription = null)
        }
    }
}

@Composable
fun MediaRow(
    title: String,
    items: List<Media>,
    onOpen: (Media) -> Unit,
    onSeeAll: (() -> Unit)? = null,
) {
    if (items.isEmpty()) return
    Column {
        SectionHeader(title, onSeeAll = onSeeAll)
        LazyRow(
            contentPadding = PaddingValues(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            items(items, key = { it.key }) { media ->
                PosterCard(
                    media = media,
                    isSaved = false,
                    onClick = { onOpen(media) },
                    onToggleSave = null,
                    modifier = Modifier.width(140.dp),
                )
            }
        }
    }
}

@Composable
fun SearchField(
    value: String,
    onValueChange: (String) -> Unit,
    modifier: Modifier = Modifier,
    placeholder: String = "Enter search query",
) {
    val focusManager = LocalFocusManager.current
    BasicTextField(
        value = value,
        onValueChange = onValueChange,
        singleLine = true,
        textStyle = MaterialTheme.typography.bodyLarge.copy(color = AppColors.TextPrimary),
        cursorBrush = SolidColor(AppColors.TextPrimary),
        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
        keyboardActions = KeyboardActions(onSearch = { focusManager.clearFocus() }),
        modifier = modifier.trackTextFieldArea(),
        decorationBox = { inner ->
            Row(
                Modifier
                    .height(52.dp)
                    .border(1.5.dp, AppColors.Outline, RoundedCornerShape(50))
                    .padding(horizontal = 16.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Icon(AppIcons.Search, contentDescription = null, tint = AppColors.Outline)
                Spacer(Modifier.width(10.dp))
                Box(Modifier.weight(1f)) {
                    if (value.isEmpty()) {
                        Text(placeholder, style = MaterialTheme.typography.bodyLarge, color = AppColors.TextSecondary)
                    }
                    inner()
                }
                if (value.isNotEmpty()) {
                    Icon(
                        AppIcons.Close,
                        contentDescription = "Clear search",
                        tint = AppColors.Outline,
                        modifier = Modifier
                            .clip(CircleShape)
                            .clickable { onValueChange("") }
                            .padding(12.dp),
                    )
                }
            }
        },
    )
}

@Composable
fun CircleIconButton(
    icon: ImageVector,
    contentDescription: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    size: Dp = 48.dp,
    showBadge: Boolean = false,
) {
    Box(modifier.size(size)) {
        Box(
            Modifier
                .fillMaxSize()
                .clip(CircleShape)
                .background(AppColors.SurfaceHigh)
                .clickable(onClick = onClick),
            contentAlignment = Alignment.Center,
        ) {
            Icon(icon, contentDescription = contentDescription, tint = AppColors.TextPrimary)
        }
        if (showBadge) {
            Box(
                Modifier
                    .align(Alignment.TopEnd)
                    .size(10.dp)
                    .clip(CircleShape)
                    .background(AppColors.Year),
            )
        }
    }
}

@Composable
fun Pill(text: String, selected: Boolean, onClick: () -> Unit, modifier: Modifier = Modifier) {
    Text(
        text = text,
        style = MaterialTheme.typography.bodyLarge,
        color = if (selected) AppColors.Background else AppColors.TextPrimary,
        modifier = modifier
            .clip(RoundedCornerShape(50))
            .background(if (selected) Color.White else AppColors.SurfaceHigh)
            .clickable(onClick = onClick)
            .padding(horizontal = 20.dp, vertical = 10.dp),
    )
}

@Composable
fun TopBar(title: String, onBack: (() -> Unit)?, modifier: Modifier = Modifier, centered: Boolean = false) {
    Box(
        modifier
            .fillMaxWidth()
            .statusBarsPadding()
            .height(56.dp)
            .padding(horizontal = 8.dp),
    ) {
        if (onBack != null) {
            Icon(
                AppIcons.Back,
                contentDescription = "Back",
                modifier = Modifier
                    .align(Alignment.CenterStart)
                    .clip(CircleShape)
                    .clickable(onClick = onBack)
                    .padding(10.dp)
                    .size(28.dp),
            )
        }
        Text(
            title,
            style = MaterialTheme.typography.titleLarge,
            color = if (centered) AppColors.TextSecondary else AppColors.TextPrimary,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = if (centered) {
                Modifier.align(Alignment.Center).padding(horizontal = 48.dp)
            } else {
                Modifier.align(Alignment.CenterStart).padding(start = if (onBack != null) 52.dp else 8.dp)
            },
        )
    }
}

@Composable
fun PrimaryButton(text: String, onClick: () -> Unit, modifier: Modifier = Modifier, enabled: Boolean = true) {
    Button(
        onClick = onClick,
        enabled = enabled,
        shape = RoundedCornerShape(50),
        colors = ButtonDefaults.buttonColors(
            containerColor = AppColors.Primary,
            disabledContainerColor = AppColors.Primary.copy(alpha = 0.35f),
        ),
        modifier = modifier.height(52.dp),
    ) {
        Text(text, style = MaterialTheme.typography.labelLarge, color = Color.White)
    }
}

@Composable
fun ExpandableText(text: String, modifier: Modifier = Modifier, collapsedLines: Int = 4) {
    var expanded by rememberSaveable { mutableStateOf(false) }
    var overflows by remember { mutableStateOf(false) }
    Column(modifier) {
        Text(
            text,
            style = MaterialTheme.typography.bodyLarge,
            maxLines = if (expanded) Int.MAX_VALUE else collapsedLines,
            overflow = TextOverflow.Ellipsis,
            onTextLayout = { if (!expanded) overflows = it.hasVisualOverflow },
        )
        if (overflows || expanded) {
            Text(
                if (expanded) "Show Less" else "Read More",
                style = MaterialTheme.typography.labelLarge,
                color = AppColors.Link,
                textAlign = TextAlign.Center,
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { expanded = !expanded }
                    .padding(vertical = 8.dp),
            )
        }
    }
}

@Composable
fun LoadingState(modifier: Modifier = Modifier) {
    Box(modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        CircularProgressIndicator(color = AppColors.Primary)
    }
}

@Composable
fun MessageState(message: String, modifier: Modifier = Modifier, onRetry: (() -> Unit)? = null) {
    Column(
        modifier
            .fillMaxSize()
            .padding(32.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text(message, style = MaterialTheme.typography.bodyLarge, color = AppColors.TextSecondary, textAlign = TextAlign.Center)
        if (onRetry != null) {
            Spacer(Modifier.height(16.dp))
            PrimaryButton("Retry", onRetry, Modifier.width(160.dp))
        }
    }
}

/** Calls [onLoadMore] when the user scrolls close to the end of a grid. */
@Composable
fun LoadMoreEffect(state: LazyGridState, onLoadMore: () -> Unit) {
    val currentOnLoadMore by rememberUpdatedState(onLoadMore)
    LaunchedEffect(state) {
        snapshotFlow {
            val last = state.layoutInfo.visibleItemsInfo.lastOrNull()?.index ?: return@snapshotFlow false
            last >= state.layoutInfo.totalItemsCount - 6
        }
            .distinctUntilChanged()
            .filter { it }
            .collect { currentOnLoadMore() }
    }
}
