package com.movies.myapplication.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.LocalContentColor
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

object AppColors {
    val Background = Color(0xFF0E1A26)
    val BackgroundTop = Color(0xFF1C3247)
    val Surface = Color(0xFF182A3B)
    val SurfaceHigh = Color(0xFF263D53)
    val Glass = Color(0xCC1E3144)
    val Outline = Color(0xFF8FA3B8)
    val Primary = Color(0xFF6A9BC3)
    val TextPrimary = Color(0xFFF2F5F8)
    val TextSecondary = Color(0xFF8C9DB0)
    val Star = Color(0xFFF5C518)
    val Year = Color(0xFFE53935)
    val Link = Color(0xFF4DA3FF)
}

val AppBackground = Brush.verticalGradient(listOf(AppColors.BackgroundTop, AppColors.Background, AppColors.Background))

private val colorScheme = darkColorScheme(
    primary = AppColors.Primary,
    onPrimary = Color.White,
    background = AppColors.Background,
    onBackground = AppColors.TextPrimary,
    surface = AppColors.Surface,
    onSurface = AppColors.TextPrimary,
    surfaceVariant = AppColors.SurfaceHigh,
    onSurfaceVariant = AppColors.TextSecondary,
    outline = AppColors.Outline,
)

private val typography = Typography(
    headlineMedium = TextStyle(fontSize = 28.sp, fontWeight = FontWeight.Bold, lineHeight = 34.sp),
    headlineSmall = TextStyle(fontSize = 24.sp, fontWeight = FontWeight.SemiBold, lineHeight = 30.sp),
    titleLarge = TextStyle(fontSize = 21.sp, fontWeight = FontWeight.SemiBold, lineHeight = 28.sp),
    titleMedium = TextStyle(fontSize = 17.sp, fontWeight = FontWeight.SemiBold, lineHeight = 22.sp),
    bodyLarge = TextStyle(fontSize = 16.sp, lineHeight = 23.sp),
    bodyMedium = TextStyle(fontSize = 14.sp, lineHeight = 20.sp),
    bodySmall = TextStyle(fontSize = 12.sp, lineHeight = 16.sp),
    labelLarge = TextStyle(fontSize = 15.sp, fontWeight = FontWeight.SemiBold),
)

@Composable
fun MovieTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = colorScheme, typography = typography) {
        // Screens draw on a custom gradient rather than a Surface, so set the default
        // text/icon color here; otherwise it falls back to black.
        CompositionLocalProvider(LocalContentColor provides AppColors.TextPrimary, content = content)
    }
}
