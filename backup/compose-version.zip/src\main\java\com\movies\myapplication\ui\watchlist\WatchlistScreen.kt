package com.movies.myapplication.ui.watchlist

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import com.movies.myapplication.data.WatchlistRepository
import com.movies.myapplication.data.model.Media
import com.movies.myapplication.data.model.MediaType
import com.movies.myapplication.ui.components.BottomBarSpace
import com.movies.myapplication.ui.components.MessageState
import com.movies.myapplication.ui.components.Pill
import com.movies.myapplication.ui.components.PosterCard
import com.movies.myapplication.ui.components.TopBar
import com.movies.myapplication.ui.mvi.MviStore
import com.movies.myapplication.ui.navigation.ScrollToTopOnTabSelect
import com.movies.myapplication.ui.rememberStore
import kotlinx.coroutines.launch

data class WatchlistUiState(val type: MediaType = MediaType.MOVIE, val items: List<Media> = emptyList()) {
    val visible: List<Media> get() = items.filter { it.type == type }
}

sealed interface WatchlistIntent {
    data class SelectType(val type: MediaType) : WatchlistIntent
    data class Remove(val media: Media) : WatchlistIntent
}

class WatchlistStore(
    private val watchlist: WatchlistRepository,
) : MviStore<WatchlistUiState, WatchlistIntent, Nothing>(WatchlistUiState()) {

    init {
        viewModelScope.launch { watchlist.items.collect { items -> reduce { copy(items = items) } } }
    }

    override fun onIntent(intent: WatchlistIntent) {
        when (intent) {
            is WatchlistIntent.SelectType -> reduce { copy(type = intent.type) }
            is WatchlistIntent.Remove -> watchlist.toggle(intent.media)
        }
    }
}

@Composable
fun WatchlistScreen(onOpenMedia: (Media) -> Unit) {
    val store = rememberStore { WatchlistStore(it.watchlist) }
    val state by store.state.collectAsStateWithLifecycle()
    val type = state.type
    val visible = state.visible
    val gridState = rememberLazyGridState()
    ScrollToTopOnTabSelect { gridState.scrollToItem(0) }

    Column(Modifier.fillMaxSize()) {
        TopBar("Watchlist", onBack = null, centered = true)
        Row(
            Modifier.padding(horizontal = 16.dp, vertical = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Pill("Movie", selected = type == MediaType.MOVIE, onClick = { store.onIntent(WatchlistIntent.SelectType(MediaType.MOVIE)) })
            Pill("TV Shows", selected = type == MediaType.TV, onClick = { store.onIntent(WatchlistIntent.SelectType(MediaType.TV)) })
        }
        if (visible.isEmpty()) {
            MessageState("Nothing saved yet. Tap the bookmark on any title to add it here.")
        } else {
            LazyVerticalGrid(
                columns = GridCells.Fixed(3),
                state = gridState,
                contentPadding = PaddingValues(start = 12.dp, end = 12.dp, top = 8.dp, bottom = BottomBarSpace),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalArrangement = Arrangement.spacedBy(18.dp),
                modifier = Modifier.fillMaxSize(),
            ) {
                items(visible, key = { it.key }) { media ->
                    PosterCard(
                        media = media,
                        isSaved = true,
                        onClick = { onOpenMedia(media) },
                        onToggleSave = { store.onIntent(WatchlistIntent.Remove(media)) },
                    )
                }
            }
        }
    }
}
