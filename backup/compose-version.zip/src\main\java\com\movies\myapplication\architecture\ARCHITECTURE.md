# Architecture

Single-module Android app (`:app`) in Kotlin, built with Jetpack Compose. The UI follows **MVI (Model-View-Intent)**
on top of a repository-based data layer, with manual dependency injection.

**Stack at a glance:** Kotlin · Jetpack Compose + Material 3 · MVI · Coroutines/Flow · Retrofit + OkHttp ·
kotlinx.serialization · DataStore Preferences (local storage) · Coil 3 · Navigation Compose · Credential Manager.
Full list with versions in [section 7](#7-tech-stack).

```
┌────────────────────────────── UI layer (ui/) ───────────────────────────────┐
│                                                                             │
│   Screen (@Composable)  ──Intent──▶  Store (MviStore<State, Intent, Effect>) │
│        ▲                                   │                                │
│        └──────── State (StateFlow) ◀───────┤  reduce { copy(...) }           │
│        └──────── Effect (Channel)  ◀───────┘  one-off: navigate, toast      │
│                                                                             │
└──────────────────────────────────┬──────────────────────────────────────────┘
                                   │ calls
┌──────────────────────────── Data layer (data/) ─────────────────────────────┐
│  MediaRepository ── TmdbApi (Retrofit + OkHttp, HTTP cache, API-key header)  │
│  WatchlistRepository ── DataStore "watchlist" (JSON list of Media)          │
│  AccountRepository  ── DataStore "account"   (name/email/photo only)        │
│  SettingsRepository ── DataStore "settings"  (last watch country)           │
│  model/ (Media, MediaDetails, Filters…)   remote/Dtos.kt (TMDB JSON → model) │
└──────────────────────────────────┬──────────────────────────────────────────┘
                                   │ built once by
┌──────────────────────────── DI (MovieApp.kt) ───────────────────────────────┐
│  MovieApp (Application) → AppContainer: Json, OkHttp, Retrofit, repositories │
│  MainActivity provides it as LocalAppContainer → rememberStore { … }        │
└─────────────────────────────────────────────────────────────────────────────┘
```

## Package layout

```
com.movies.myapplication
├── MainActivity.kt          Entry point; provides LocalAppContainer, hosts MovieAppRoot
├── MovieApp.kt              Application + AppContainer (manual DI)
├── data/
│   ├── MediaRepository.kt   TMDB content
│   ├── WatchlistRepository.kt
│   ├── AccountRepository.kt
│   ├── SettingsRepository.kt
│   ├── model/               Domain models (Media, MediaDetails, DiscoverFilter, Mood…)
│   └── remote/              TmdbApi (Retrofit) + DTOs
└── ui/
    ├── mvi/Mvi.kt           MviStore base class + CollectEffects
    ├── AppSupport.kt        rememberStore, safeCall, error messages, formatters
    ├── navigation/          Routes, NavHost, floating bottom bar
    ├── components/          Stateless shared composables
    ├── theme/               Colors, icons, typography
    ├── home/  browse/  category/  details/  person/  mood/  watchlist/  profile/
    └── YouTube.kt           Trailer / search intents
```

## 1. MVI core (`ui/mvi/Mvi.kt`)

`MviStore<S, I, E>` is the base of every screen's logic:

| Member | Role |
|---|---|
| `state: StateFlow<S>` | One immutable data class, the single source of truth for the screen |
| `onIntent(intent: I)` | The only entry point for user actions |
| `effects: Flow<E>` | One-off events (navigation, toasts) delivered through a `Channel`, never replayed on recomposition |
| `reduce { copy(...) }` | The only way a store changes its state |
| `currentState` | Read the latest state inside the store |

It extends Jetpack's `ViewModel` only to be scoped to the screen's lifecycle (survives rotation, lives as long as the
back-stack entry). Screens talk to it solely via `state`, `effects` and `onIntent`. Screens without effects use
`Nothing` for `E`.

Helpers:

- `rememberStore { container -> XxxStore(...) }` (`ui/AppSupport.kt`) creates a screen-scoped store from `AppContainer`.
  Pass `key` when one screen holds several stores of the same type.
- `CollectEffects(store.effects) { effect -> … }` handles effects on the screen side.

### Data flow of one action

```
User taps bookmark
  → store.onIntent(HomeIntent.ToggleSave(media))
  → HomeStore: watchlist.toggle(media)
  → DataStore updates → watchlist.keys emits
  → HomeStore: reduce { copy(savedKeys = keys) }
  → Compose re-renders from the new state
```

### Screen contract pattern

Each feature file contains, in order: `UiState`, `sealed interface Intent`, optional `sealed interface Effect`, the
`Store`, and the `@Composable` screen.

```kotlin
data class PersonUiState(val person: Person? = null, val isLoading: Boolean = true, val error: String? = null)

sealed interface PersonIntent {
    data object Retry : PersonIntent
}

class PersonStore(
    private val repository: MediaRepository,
    private val id: Int,
) : MviStore<PersonUiState, PersonIntent, Nothing>(PersonUiState()) {

    init { load() }

    override fun onIntent(intent: PersonIntent) {
        when (intent) {
            PersonIntent.Retry -> load()
        }
    }

    private fun load() { /* reduce { … } */ }
}

@Composable
fun PersonScreen(route: PersonRoute, onBack: () -> Unit, onOpenMedia: (Media) -> Unit) {
    val store = rememberStore { PersonStore(it.mediaRepository, route.id) }
    val state by store.state.collectAsStateWithLifecycle()
    // render state; send store.onIntent(...) on user actions
}
```

## 2. Screens

| Feature | Store | Repositories | Intents | Effects |
|---|---|---|---|---|
| `home/` | `HomeStore` | Media, Watchlist | `Retry`, `ToggleSave` | – |
| `browse/` | `BrowseStore` (search with 400 ms debounce, filters, paging) | Media, Watchlist | `QueryChanged`, `OpenFilters`, `CloseFilters`, `ApplyFilter`, `RegionChanged`, `LoadMore`, `Retry`, `ToggleSave` | – |
| `category/` | `CategoryStore` (paged grid) | Media | `LoadMore`, `Retry` | – |
| `details/` | `DetailsStore` | Media, Watchlist | `Retry`, `SelectSeason`, `ToggleSave` | – |
| `details/` | `SeasonStore` | Media | `Select`, `Retry` | – |
| `details/` | `EpisodeStore` | Media | `Retry` | – |
| `person/` | `PersonStore` | Media | `Retry` | – |
| `mood/` | `MoodStore` | Media, Watchlist | `ToggleMood`, `Apply`, `ToggleSave` | `OpenResults` |
| `mood/` | `MoodResultsScreen` reuses two `BrowseStore`s (Movies / TV tabs) | Media, Watchlist | – | – |
| `watchlist/` | `WatchlistStore` | Watchlist | `SelectType`, `Remove` | – |
| `profile/` | `ProfileStore` (guest / Google sign-in, logout, delete) | Account, Watchlist | `OpenLogin`, `DismissLogin`, `ContinueAsGuest`, `ContinueWithGoogle`, `GoogleSignInFinished`, `Logout`, `RequestDelete`, `DismissDelete`, `ConfirmDelete` | `LaunchGoogleSignIn`, `ClearGoogleCredentials`, `ShowMessage` |

Effects are used only for work that needs an Activity `Context` (Credential Manager, toasts) or for navigating as the
result of an intent. Paging fields (`page`, `hasMore`, `loadedQuery`) live in the state as well; the only things kept
outside it are `Job` handles used to cancel in-flight requests.

## 3. Navigation (`ui/navigation/Navigation.kt`)

- Navigation Compose with type-safe `@Serializable` routes: `HomeRoute`, `WatchlistRoute`, `MoodRoute`, `ProfileRoute`,
  `BrowseRoute`, `CategoryRoute`, `MoodResultsRoute`, `DetailsRoute`, `SeasonRoute`, `EpisodeRoute`, `PersonRoute`.
- Four bottom tabs (Home, Watchlist, Mood, Profile) in a floating glass bar. Tab switches use `saveState` /
  `restoreState`, so each tab keeps its store and scroll position.
- Screens receive navigation as callbacks (`onOpenMedia`, `onNavigate`, `onBack`); stores never hold a `NavController`.

## 4. Shared UI

- `ui/components/`: stateless composables that get data and callbacks from the screen: `PagedMediaGrid` (infinite
  scroll over the `PagedContent` interface), `MediaRow`, `PosterCard`, `InfoCard`, `Pill`, `TopBar`, `SearchField`,
  glass/haze blur helpers, keyboard dismissal.
- `ui/theme/`: `AppColors`, `AppIcons`, typography.
- `ui/AppSupport.kt`: `safeCall` (wraps a call in `Result`, rethrows coroutine cancellation), `toUserMessage()`
  (network/HTTP errors to readable text), date and runtime formatters.

## 5. Data layer (`data/`)

| Class | Backed by | API |
|---|---|---|
| `MediaRepository` | `TmdbApi` (Retrofit) | trending, popular, top rated, discover, search, details, seasons, episodes, person, genres, watch providers; maps DTOs to domain models |
| `WatchlistRepository` | DataStore `watchlist` | `items`, `keys` (`StateFlow`), `toggle()`, `clear()` |
| `AccountRepository` | DataStore `account` | `account: StateFlow<Account?>`, `signIn()`, `signOut()`; display details only, no tokens |
| `SettingsRepository` | DataStore `settings` | `watchCountry: StateFlow<String>` (default `US`), `setWatchCountry()` |

## 6. Dependency injection (`MovieApp.kt`)

Manual. `AppContainer` is created once in `MovieApp.onCreate()` and builds:

- one `OkHttpClient` (10 MB HTTP cache, timeouts, interceptor adding the TMDB API key),
- one Retrofit `TmdbApi` with kotlinx.serialization,
- the four repositories, sharing an app-wide `CoroutineScope` for storage writes.

`MainActivity` exposes the container to Compose as `LocalAppContainer`, which `rememberStore` reads.

## 7. Tech stack

What the app uses for each job. Versions come from `gradle/libs.versions.toml`.

### Language and build

| Concern | Used | Version |
|---|---|---|
| Language | Kotlin | 2.4.20 |
| Build system | Gradle (Kotlin DSL) + Android Gradle Plugin, version catalog `libs.versions.toml` | AGP 9.4.1 |
| SDK levels | `minSdk` 26 (Android 8.0), `targetSdk` / `compileSdk` 37 | – |
| Java target | Java 11 bytecode | – |
| Release optimization | R8 (shrink + optimize) and `androidx.profileinstaller` (baseline profiles) | profileinstaller 1.4.1 |
| Secrets | `TMDB_API_KEY` and `GOOGLE_WEB_CLIENT_ID` read from `local.properties` (git-ignored) into `BuildConfig` | – |

### UI

| Concern | Used | Version |
|---|---|---|
| UI toolkit | Jetpack Compose | Compose BOM 2026.09.00 |
| Design system | Material 3 | from Compose BOM |
| Activity host | `androidx.activity:activity-compose` (single Activity) | 1.13.0 |
| Navigation | Navigation Compose with type-safe `@Serializable` routes | 2.10.2 |
| Image loading | Coil 3 (`coil-compose` + `coil-network-okhttp`) | 3.6.3 |
| Blur / glass effect | Haze (`haze-blur`) | 2.0.1 |

### Architecture and state

| Concern | Used | Version |
|---|---|---|
| Pattern | MVI: own `MviStore` base class (see section 1) | – |
| Lifecycle scoping | `lifecycle-viewmodel-compose` (stores extend `ViewModel`), `lifecycle-runtime-compose` (`collectAsStateWithLifecycle`) | 2.11.0 |
| Async / streams | Kotlin Coroutines + Flow (`StateFlow` for state, `Channel` for effects) | via Kotlin / AndroidX |
| Dependency injection | Manual: `AppContainer` in `MovieApp.kt` | – |

### Networking

| Concern | Used | Version |
|---|---|---|
| Backend | TMDB REST API v3 (`https://api.themoviedb.org/3/`) | – |
| HTTP client | OkHttp (10 MB disk cache, 15 s connect / 20 s read timeout, API-key interceptor) | 5.5.0 |
| REST client | Retrofit (`TmdbApi` interface, suspend functions) | 3.0.0 |
| JSON | kotlinx.serialization (`ignoreUnknownKeys`, `coerceInputValues`) with Retrofit's kotlinx-serialization converter | 1.11.0 |

### Local storage (database)

| Concern | Used | Version |
|---|---|---|
| Watchlist | DataStore Preferences, file `watchlist`: the whole list stored as one JSON string (`List<Media>`) | 1.2.1 |
| Account | DataStore Preferences, file `account`: name, email, photo URL, guest flag (no tokens) | 1.2.1 |
| Settings | DataStore Preferences, file `settings`: last country picked in Watch Availability | 1.2.1 |
| API response cache | OkHttp disk cache in `cacheDir/tmdb_http` | – |
| Image cache | Coil's memory and disk cache | – |

### Authentication

| Concern | Used | Version |
|---|---|---|
| Sign-in | Credential Manager (`androidx.credentials` + `credentials-play-services-auth`) | 1.6.0 |
| Google account | Google Identity (`googleid`, Sign in with Google) | 1.2.1 |
| Guest mode | Local only, stored in DataStore | – |

### Testing

| Concern | Used | Version |
|---|---|---|
| Unit tests | JUnit 4 | 4.13.2 |
| Instrumented tests | AndroidX JUnit, Espresso | 1.3.0 / 3.7.0 |
