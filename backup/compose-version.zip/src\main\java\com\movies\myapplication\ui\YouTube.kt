package com.movies.myapplication.ui

import android.app.SearchManager
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.core.net.toUri
import com.movies.myapplication.data.model.Video

private const val YOUTUBE_PACKAGE = "com.google.android.youtube"

/** Plays [video] in the YouTube app, falling back to the browser when the app isn't installed. */
fun Context.playOnYouTube(video: Video) =
    launchInYouTube(Intent(Intent.ACTION_VIEW, video.url.toUri()), video.url)

/** Opens a YouTube search for [query] in the YouTube app, falling back to the browser. */
fun Context.searchOnYouTube(query: String) =
    launchInYouTube(
        Intent(Intent.ACTION_SEARCH).putExtra(SearchManager.QUERY, query),
        "https://www.youtube.com/results?search_query=${Uri.encode(query)}",
    )

private fun Context.launchInYouTube(appIntent: Intent, webUrl: String) {
    try {
        startActivity(appIntent.setPackage(YOUTUBE_PACKAGE))
    } catch (_: ActivityNotFoundException) {
        // No YouTube app; a missing browser must not crash the app either.
        runCatching { startActivity(Intent(Intent.ACTION_VIEW, webUrl.toUri())) }
    }
}
