package com.movies.myapplication.ui.components

import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.State
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.movies.myapplication.ui.theme.AppColors

/*
 * Grey placeholders shaped like the content that is loading. All blocks on a screen share one
 * pulse so they breathe together; the alpha is read in the draw phase, so pulsing never recomposes.
 */

@Composable
private fun rememberPulse(): State<Float> = rememberInfiniteTransition(label = "skeleton").animateFloat(
    initialValue = 0.45f,
    targetValue = 0.9f,
    animationSpec = infiniteRepeatable(tween(durationMillis = 850), RepeatMode.Reverse),
    label = "skeletonAlpha",
)

@Composable
private fun SkeletonBlock(pulse: State<Float>, modifier: Modifier, shape: Shape = RoundedCornerShape(8.dp)) {
    Box(
        modifier
            .graphicsLayer { alpha = pulse.value }
            .clip(shape)
            .background(AppColors.SurfaceHigh),
    )
}

@Composable
private fun PosterSkeleton(pulse: State<Float>, modifier: Modifier = Modifier) {
    Column(modifier) {
        SkeletonBlock(
            pulse,
            Modifier
                .fillMaxWidth()
                .aspectRatio(2f / 3f),
            RoundedCornerShape(12.dp),
        )
        Spacer(Modifier.height(8.dp))
        SkeletonBlock(
            pulse,
            Modifier
                .fillMaxWidth(0.85f)
                .height(14.dp),
        )
        Spacer(Modifier.height(6.dp))
        SkeletonBlock(
            pulse,
            Modifier
                .fillMaxWidth(0.55f)
                .height(12.dp),
        )
    }
}

/** Stands in for [PagedMediaGrid] while its first page loads. */
@Composable
fun PosterGridSkeleton(modifier: Modifier = Modifier) {
    val pulse = rememberPulse()
    LazyVerticalGrid(
        columns = GridCells.Fixed(3),
        contentPadding = PaddingValues(start = 12.dp, end = 12.dp, top = 4.dp, bottom = 24.dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp),
        userScrollEnabled = false,
        modifier = modifier
            .fillMaxSize()
            .semantics { contentDescription = "Loading" },
    ) {
        items(12) { PosterSkeleton(pulse) }
    }
}

/** Stands in for the Home screen (hero card and poster rows) while it first loads. */
@Composable
fun HomeSkeleton(heroHeight: Dp, modifier: Modifier = Modifier) {
    val pulse = rememberPulse()
    Column(
        modifier
            .fillMaxSize()
            .semantics { contentDescription = "Loading" },
    ) {
        SkeletonBlock(
            pulse,
            Modifier
                .fillMaxWidth()
                .height(heroHeight),
            RoundedCornerShape(0.dp),
        )
        repeat(2) {
            SkeletonBlock(
                pulse,
                Modifier
                    .padding(start = 16.dp, top = 20.dp, bottom = 12.dp)
                    .width(180.dp)
                    .height(22.dp),
            )
            Row(
                Modifier.padding(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                repeat(3) { PosterSkeleton(pulse, Modifier.width(140.dp)) }
            }
        }
    }
}
