package com.movies.myapplication

import android.app.Application
import android.content.Context
import androidx.datastore.preferences.preferencesDataStore
import coil3.ImageLoader
import coil3.PlatformContext
import coil3.SingletonImageLoader
import coil3.network.okhttp.OkHttpNetworkFetcherFactory
import coil3.request.crossfade
import com.movies.myapplication.data.AccountRepository
import com.movies.myapplication.data.MediaRepository
import com.movies.myapplication.data.SettingsRepository
import com.movies.myapplication.data.WatchlistRepository
import com.movies.myapplication.data.remote.TmdbApi
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.serialization.json.Json
import okhttp3.Cache
import okhttp3.Interceptor
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Response
import retrofit2.Retrofit
import retrofit2.converter.kotlinx.serialization.asConverterFactory
import retrofit2.create
import java.io.File
import java.io.IOException
import java.util.concurrent.TimeUnit

private val Context.watchlistStore by preferencesDataStore(name = "watchlist")
private val Context.accountStore by preferencesDataStore(name = "account")
private val Context.settingsStore by preferencesDataStore(name = "settings")

class MovieApp : Application(), SingletonImageLoader.Factory {

    lateinit var container: AppContainer
        private set

    override fun onCreate() {
        super.onCreate()
        container = AppContainer(this)
    }

    // Images go through the same healthy connection setup as the API (but without the API key).
    override fun newImageLoader(context: PlatformContext): ImageLoader =
        ImageLoader.Builder(context)
            .components { add(OkHttpNetworkFetcherFactory(callFactory = { container.baseHttpClient })) }
            .crossfade(true)
            .build()
}

/** Manual dependency graph: one shared HTTP client, API and repositories for the whole app. */
class AppContainer(context: Context) {

    private val json = Json {
        ignoreUnknownKeys = true
        coerceInputValues = true
    }

    /**
     * Shared by API calls and image downloads. A connection left idle can be dropped silently by
     * Wi-Fi or a router; without these settings the next request hangs on it until it times out.
     */
    val baseHttpClient: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        // HTTP/2 pings notice a dead connection within seconds, so it is replaced before a request waits on it.
        .pingInterval(10, TimeUnit.SECONDS)
        .addInterceptor(RetryOnceInterceptor)
        .build()

    private val httpClient = baseHttpClient.newBuilder()
        .cache(Cache(File(context.cacheDir, "tmdb_http"), 10L * 1024 * 1024))
        // The key is attached here, in one place, and only ever sent over HTTPS to TMDB.
        .addInterceptor { chain ->
            val request = chain.request()
            val url = request.url.newBuilder()
                .addQueryParameter("api_key", BuildConfig.TMDB_API_KEY)
                .build()
            chain.proceed(request.newBuilder().url(url).build())
        }
        .build()

    private val api: TmdbApi = Retrofit.Builder()
        .baseUrl("https://api.themoviedb.org/3/")
        .client(httpClient)
        .addConverterFactory(json.asConverterFactory("application/json".toMediaType()))
        .build()
        .create()

    val mediaRepository = MediaRepository(api)

    private val storageScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    val watchlist = WatchlistRepository(
        dataStore = context.applicationContext.watchlistStore,
        json = json,
        scope = storageScope,
    )

    val account = AccountRepository(context.applicationContext.accountStore, storageScope)

    val settings = SettingsRepository(context.applicationContext.settingsStore, storageScope)
}

/**
 * Retries a GET once when the connection stalls or drops mid-request; OkHttp gives the retry a fresh
 * connection. A request the user abandoned (cancelled) is not retried.
 */
private object RetryOnceInterceptor : Interceptor {
    override fun intercept(chain: Interceptor.Chain): Response {
        val request = chain.request()
        return try {
            chain.proceed(request)
        } catch (e: IOException) {
            if (request.method != "GET" || chain.call().isCanceled()) throw e
            chain.proceed(request)
        }
    }
}
