package com.movies.myapplication.ui.mvi

import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberUpdatedState
import androidx.lifecycle.ViewModel
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.receiveAsFlow
import kotlinx.coroutines.flow.update

/**
 * Model-View-Intent base. The UI renders one immutable [S]tate, reports everything the user does as an [I]ntent
 * through [onIntent], and receives one-off [E]ffects (navigation, toasts) that must not replay on recomposition.
 * Screens without effects use `Nothing` for [E].
 *
 * It extends Jetpack's ViewModel only to be scoped to the screen's lifecycle; screens talk to it solely via
 * [state], [effects] and [onIntent].
 */
abstract class MviStore<S, I, E>(initialState: S) : ViewModel() {

    private val _state = MutableStateFlow(initialState)
    val state: StateFlow<S> = _state.asStateFlow()

    private val _effects = Channel<E>(Channel.BUFFERED)
    val effects: Flow<E> = _effects.receiveAsFlow()

    protected val currentState: S get() = _state.value

    /** The single entry point for user actions. */
    abstract fun onIntent(intent: I)

    /** Produces the next state from the current one. */
    protected fun reduce(transform: S.() -> S) = _state.update(transform)

    protected fun postEffect(effect: E) {
        _effects.trySend(effect)
    }
}

/** Handles a store's one-off effects while the calling screen is shown. */
@Composable
fun <E> CollectEffects(effects: Flow<E>, onEffect: suspend (E) -> Unit) {
    val handler by rememberUpdatedState(onEffect)
    LaunchedEffect(effects) {
        effects.collect { handler(it) }
    }
}
