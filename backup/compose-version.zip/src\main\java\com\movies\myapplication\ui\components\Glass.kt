package com.movies.myapplication.ui.components

import androidx.compose.foundation.border
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.unit.dp
import com.movies.myapplication.ui.theme.AppColors
import dev.chrisbanes.haze.HazeInput
import dev.chrisbanes.haze.HazePerformanceMode
import dev.chrisbanes.haze.HazeState
import dev.chrisbanes.haze.blur.HazeBlurStyle
import dev.chrisbanes.haze.blur.HazeColorEffect
import dev.chrisbanes.haze.blur.hazeBlur

/** Dark tone for panels (cards, nav bar); Button tone for small round buttons over artwork. */
enum class GlassTone(
    internal val style: HazeBlurStyle,
    internal val borderAlpha: Float,
    internal val performanceMode: HazePerformanceMode = HazePerformanceMode.Default,
) {
    Dark(
        HazeBlurStyle {
            blurRadius(24.dp)
            backgroundColor(AppColors.Background)
            colorEffects(listOf(HazeColorEffect.tint(AppColors.Glass.copy(alpha = 0.4f))))
            // Android 11 and older can't blur reliably; a solid tint keeps text readable there.
            fallbackColorEffect(HazeColorEffect.tint(AppColors.Glass))
        },
        borderAlpha = 0.12f,
    ),

    /** Same colors as an unselected bottom-bar button: dark glass plus a faint white fill. */
    Button(
        HazeBlurStyle {
            // A small radius keeps the dark page around a poster's corner from bleeding into the button.
            blurRadius(12.dp)
            colorEffects(
                listOf(
                    HazeColorEffect.tint(AppColors.Glass.copy(alpha = 0.4f)),
                    HazeColorEffect.tint(Color.White.copy(alpha = 0.06f)),
                ),
            )
            fallbackColorEffect(HazeColorEffect.tint(AppColors.Glass))
        },
        borderAlpha = 0.15f,
        // One of these sits on every poster in a scrolling grid; a downsampled blur looks the same at this size.
        performanceMode = HazePerformanceMode.Performance,
    ),
}

/** Frosted-glass background that blurs whatever the `hazeSource(state)` content draws behind it. */
fun Modifier.glass(state: HazeState, shape: Shape, tone: GlassTone = GlassTone.Dark): Modifier =
    clip(shape)
        .hazeBlur(HazeInput.Sources(state), tone.style, tone.performanceMode)
        .border(1.dp, Color.White.copy(alpha = tone.borderAlpha), shape)
