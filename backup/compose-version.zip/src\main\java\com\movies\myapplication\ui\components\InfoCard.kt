package com.movies.myapplication.ui.components

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.movies.myapplication.ui.theme.AppColors
import dev.chrisbanes.haze.HazeState

/** The frosted-glass card used over hero artwork on Home and Details; blurs [hazeState]'s source. */
@Composable
fun InfoCard(
    hazeState: HazeState,
    title: String,
    rating: Double,
    meta: String,
    actionLabel: String,
    onAction: () -> Unit,
    isSaved: Boolean,
    onToggleSave: () -> Unit,
    modifier: Modifier = Modifier,
    overview: String? = null,
) {
    Column(
        modifier
            .fillMaxWidth()
            .glass(hazeState, RoundedCornerShape(20.dp))
            .padding(20.dp),
    ) {
        Text(title, style = MaterialTheme.typography.headlineSmall, maxLines = 2, overflow = TextOverflow.Ellipsis)
        Rating(rating, Modifier.padding(top = 6.dp))
        if (meta.isNotEmpty()) {
            Text(meta, style = MaterialTheme.typography.bodyMedium, color = AppColors.TextSecondary, modifier = Modifier.padding(top = 4.dp))
        }
        if (!overview.isNullOrBlank()) {
            ExpandableText(overview, Modifier.padding(top = 10.dp), collapsedLines = 3)
        }
        Spacer(Modifier.height(16.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Button(
                onClick = onAction,
                shape = RoundedCornerShape(50),
                colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = AppColors.Background),
                modifier = Modifier
                    .weight(1f)
                    .height(52.dp),
            ) {
                Text(actionLabel, style = MaterialTheme.typography.titleMedium)
            }
            Spacer(Modifier.width(12.dp))
            BookmarkButton(isSaved = isSaved, onClick = onToggleSave, hazeState = hazeState, size = 52.dp)
        }
    }
}
