package com.movies.myapplication.ui.components

import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.waitForUpOrCancellation
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusManager
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.boundsInRoot
import androidx.compose.ui.layout.onGloballyPositioned

/** Screen area of the text field currently on screen, so taps on it don't dismiss the keyboard. */
class TextFieldArea {
    var bounds: Rect? = null
}

val LocalTextFieldArea = staticCompositionLocalOf { TextFieldArea() }

/**
 * Clears focus (hiding the keyboard) when a tap lands anywhere outside the text field.
 * Observes the Initial pass so it sees taps before buttons consume them, without blocking them.
 */
fun Modifier.dismissKeyboardOnTapOutside(focusManager: FocusManager, area: TextFieldArea): Modifier =
    pointerInput(focusManager, area) {
        awaitEachGesture {
            val down = awaitFirstDown(requireUnconsumed = false, pass = PointerEventPass.Initial)
            if (area.bounds?.contains(down.position) == true) return@awaitEachGesture
            // A drag/scroll cancels the tap; scrolling screens handle that case themselves.
            if (waitForUpOrCancellation(PointerEventPass.Initial) != null) focusManager.clearFocus()
        }
    }

/** Registers this text field's on-screen area with [LocalTextFieldArea]. */
@Composable
fun Modifier.trackTextFieldArea(): Modifier {
    val area = LocalTextFieldArea.current
    DisposableEffect(area) { onDispose { area.bounds = null } }
    return onGloballyPositioned { area.bounds = it.boundsInRoot() }
}
