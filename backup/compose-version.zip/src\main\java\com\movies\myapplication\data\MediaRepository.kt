package com.movies.myapplication.data

import com.movies.myapplication.data.model.Country
import com.movies.myapplication.data.model.Credit
import com.movies.myapplication.data.model.DiscoverFilter
import com.movies.myapplication.data.model.Episode
import com.movies.myapplication.data.model.EpisodeDetails
import com.movies.myapplication.data.model.Genre
import com.movies.myapplication.data.model.Media
import com.movies.myapplication.data.model.MediaDetails
import com.movies.myapplication.data.model.MediaType
import com.movies.myapplication.data.model.OfferType
import com.movies.myapplication.data.model.PageResult
import com.movies.myapplication.data.model.Person
import com.movies.myapplication.data.model.Provider
import com.movies.myapplication.data.model.SeasonInfo
import com.movies.myapplication.data.model.Video
import com.movies.myapplication.data.model.WatchAvailability
import com.movies.myapplication.data.model.WatchOffer
import com.movies.myapplication.data.remote.MediaDto
import com.movies.myapplication.data.remote.PageDto
import com.movies.myapplication.data.remote.PersonRefDto
import com.movies.myapplication.data.remote.TmdbApi
import com.movies.myapplication.data.remote.VideoDto
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.text.Collator
import java.util.Locale

class MediaRepository(private val api: TmdbApi) {

    private val genreCache = mutableMapOf<MediaType, List<Genre>>()
    private val genreMutex = Mutex()
    private var countriesCache: List<Country>? = null
    private val countriesMutex = Mutex()

    suspend fun genres(type: MediaType): List<Genre> = genreMutex.withLock {
        genreCache[type] ?: api.genres(type.path).genres
            .map { Genre(it.id, it.name) }
            .also { genreCache[type] = it }
    }

    suspend fun trending(type: MediaType?, page: Int = 1): PageResult =
        api.trending(type?.path ?: "all", if (type == null) "day" else "week", page).toResult(type)

    suspend fun popular(type: MediaType, page: Int = 1): PageResult =
        api.popular(type.path, page).toResult(type)

    suspend fun topRated(type: MediaType, page: Int = 1): PageResult =
        api.topRated(type.path, page).toResult(type)

    suspend fun discover(type: MediaType, filter: DiscoverFilter, page: Int): PageResult =
        api.discover(type.path, filter.toDiscoverParams(type, page)).toResult(type)

    /** TMDB search only supports a year filter, so genre and language are applied to the results locally. */
    suspend fun search(type: MediaType, query: String, filter: DiscoverFilter, page: Int): PageResult {
        val params = buildMap {
            put("query", query)
            put("page", page.toString())
            put("include_adult", "false")
            filter.year?.let { put(if (type == MediaType.MOVIE) "primary_release_year" else "first_air_date_year", it.toString()) }
        }
        val response = api.search(type.path, params)
        val filtered = response.results.filter { dto ->
            (filter.genreIds.isEmpty() || dto.genreIds.any { it in filter.genreIds }) &&
                (filter.language == null || dto.originalLanguage == filter.language)
        }
        return response.copy(results = filtered).toResult(type)
    }

    suspend fun providers(type: MediaType, region: String): List<Provider> =
        api.providers(type.path, region).results
            .sortedBy { it.priority }
            .take(25)
            .map { Provider(it.id, it.name) }

    /** Where a title can be watched, keyed by country code. */
    suspend fun watchAvailability(type: MediaType, id: Int): Map<String, WatchAvailability> =
        api.watchProviders(type.path, id).results.mapValues { (_, dto) ->
            val offers = listOf(
                OfferType.STREAM to dto.flatrate,
                OfferType.FREE to dto.free,
                OfferType.ADS to dto.ads,
                OfferType.RENT to dto.rent,
                OfferType.BUY to dto.buy,
            ).flatMap { (offerType, providers) ->
                providers.sortedBy { it.priority }.map { WatchOffer(it.id, it.name, it.logoPath, offerType) }
            }
            WatchAvailability(dto.link, offers)
        }

    /** Every country with watch data, named in the device language and sorted by name. Cached after the first call. */
    suspend fun countries(): List<Country> = countriesMutex.withLock {
        countriesCache ?: api.watchRegions().results
            .map { dto ->
                val localName = runCatching { Locale.Builder().setRegion(dto.code).build().displayCountry }.getOrNull()
                // Locale returns the code itself for regions it doesn't know.
                Country(dto.code, localName?.takeIf { it.isNotBlank() && it != dto.code } ?: dto.englishName.ifBlank { dto.code })
            }
            .sortedWith(compareBy(Collator.getInstance()) { it.name })
            .also { countriesCache = it }
    }

    suspend fun details(type: MediaType, id: Int): MediaDetails {
        val dto = api.details(type.path, id, append = "videos,credits,similar")
        val genreNames = dto.genres.map { it.name }
        val media = Media(
            id = dto.id,
            type = type,
            title = dto.title ?: dto.name.orEmpty(),
            posterPath = dto.posterPath,
            backdropPath = dto.backdropPath,
            overview = dto.overview.orEmpty(),
            year = (dto.releaseDate ?: dto.firstAirDate)?.take(4)?.takeIf { it.isNotBlank() },
            rating = dto.voteAverage,
            genre = genreNames.firstOrNull(),
        )
        val creators = dto.createdBy.map { Credit(it.id, it.name, "Creator", it.profilePath) } +
            dto.credits?.crew.orEmpty().keyCrew("Director")
        val cast = dto.credits?.cast.orEmpty().take(20).map { it.asCast() }
        val seasons = dto.seasons.filter { it.number > 0 }.ifEmpty { dto.seasons }
            .map { SeasonInfo(it.number, it.name, it.episodeCount) }
        return MediaDetails(
            media = media,
            genres = genreNames,
            country = dto.originCountry.firstOrNull() ?: dto.productionCountries.firstOrNull()?.code,
            videos = dto.videos?.results.orEmpty().toTrailers(),
            credits = (cast + creators).distinctBy { it.id },
            seasons = seasons,
            similar = dto.similar?.results.orEmpty().toMedia(type),
        )
    }

    suspend fun seasons(tvId: Int): List<SeasonInfo> {
        val seasons = api.details(MediaType.TV.path, tvId).seasons
        return seasons.filter { it.number > 0 }.ifEmpty { seasons }
            .map { SeasonInfo(it.number, it.name, it.episodeCount) }
    }

    suspend fun episodes(tvId: Int, season: Int): List<Episode> =
        api.season(tvId, season).episodes.map {
            Episode(it.id, it.number, it.name, it.stillPath, it.runtime, it.airDate)
        }

    suspend fun episode(tvId: Int, season: Int, episode: Int): EpisodeDetails {
        val dto = api.episode(tvId, season, episode)
        return EpisodeDetails(
            season = dto.seasonNumber,
            number = dto.number,
            name = dto.name,
            overview = dto.overview.orEmpty(),
            stillPath = dto.stillPath,
            airDate = dto.airDate,
            runtime = dto.runtime,
            rating = dto.voteAverage,
            credits = (dto.crew.keyCrew("Director", "Writer") + dto.guestStars.map { it.asCast() }).distinctBy { it.id },
            videos = dto.videos?.results.orEmpty().toTrailers(),
        )
    }

    suspend fun person(id: Int): Person {
        val dto = api.person(id)
        val credits = dto.combinedCredits?.cast.orEmpty()
            .distinctBy { it.mediaType to it.id }
            .sortedByDescending { it.popularity }
        return Person(
            id = dto.id,
            name = dto.name,
            biography = dto.biography.orEmpty(),
            birthday = dto.birthday,
            placeOfBirth = dto.placeOfBirth,
            profilePath = dto.profilePath,
            movies = credits.filter { it.mediaType == MediaType.MOVIE.path }.toMedia(MediaType.MOVIE),
            tvShows = credits.filter { it.mediaType == MediaType.TV.path }.toMedia(MediaType.TV),
        )
    }

    private fun PersonRefDto.asCast() = Credit(id, name, if (gender == 1) "Actress" else "Actor", profilePath)

    private fun List<PersonRefDto>.keyCrew(vararg jobs: String) =
        filter { it.job in jobs }.map { Credit(it.id, it.name, it.job.orEmpty(), it.profilePath) }

    private fun List<VideoDto>.toTrailers() =
        filter { it.site == "YouTube" && (it.type == "Trailer" || it.type == "Teaser") }
            .sortedBy { if (it.type == "Trailer") 0 else 1 }
            .map { Video(it.key, it.name, it.type) }

    private suspend fun PageDto<MediaDto>.toResult(type: MediaType?) =
        PageResult(results.toMedia(type), page, totalPages)

    /**
     * [fallbackType] is used when the response does not tag each item with a media type. Titles without a
     * poster are dropped: TMDB lists (especially "similar" and deep search pages) include stub entries with
     * no artwork, which would show as empty cards.
     */
    private suspend fun List<MediaDto>.toMedia(fallbackType: MediaType?): List<Media> {
        val genreNames = mutableMapOf<MediaType, Map<Int, String>>()
        return mapNotNull { dto ->
            if (dto.posterPath == null) return@mapNotNull null
            val type = when (dto.mediaType) {
                MediaType.MOVIE.path -> MediaType.MOVIE
                MediaType.TV.path -> MediaType.TV
                null -> fallbackType
                else -> null
            } ?: return@mapNotNull null
            val names = genreNames.getOrPut(type) {
                // Genre names are cosmetic; a failed lookup must not fail the whole list.
                runCatching { genres(type) }.getOrDefault(emptyList()).associate { it.id to it.name }
            }
            Media(
                id = dto.id,
                type = type,
                title = dto.title ?: dto.name.orEmpty(),
                posterPath = dto.posterPath,
                backdropPath = dto.backdropPath,
                overview = dto.overview.orEmpty(),
                year = (dto.releaseDate ?: dto.firstAirDate)?.take(4)?.takeIf { it.isNotBlank() },
                rating = dto.voteAverage,
                genre = dto.genreIds.firstNotNullOfOrNull { names[it] },
            )
        }
    }
}
