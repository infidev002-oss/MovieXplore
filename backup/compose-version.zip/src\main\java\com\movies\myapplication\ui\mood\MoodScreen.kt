package com.movies.myapplication.ui.mood

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.selection.toggleable
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.heading
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import com.movies.myapplication.data.MediaRepository
import com.movies.myapplication.data.model.Media
import com.movies.myapplication.data.model.MediaType
import com.movies.myapplication.data.model.Mood
import com.movies.myapplication.ui.components.BottomBarSpace
import com.movies.myapplication.ui.components.MediaRow
import com.movies.myapplication.ui.components.PrimaryButton
import com.movies.myapplication.ui.components.StatusBarScrim
import com.movies.myapplication.ui.mvi.CollectEffects
import com.movies.myapplication.ui.mvi.MviStore
import com.movies.myapplication.ui.navigation.CategoryList
import com.movies.myapplication.ui.navigation.CategoryRoute
import com.movies.myapplication.ui.navigation.MoodResultsRoute
import com.movies.myapplication.ui.navigation.ScrollToTopOnTabSelect
import com.movies.myapplication.ui.rememberStore
import com.movies.myapplication.ui.safeCall
import com.movies.myapplication.ui.theme.AppColors
import com.movies.myapplication.ui.theme.AppIcons
import kotlinx.coroutines.launch

data class MoodUiState(
    val selected: Set<Mood> = emptySet(),
    val popularMovies: List<Media> = emptyList(),
    val popularTv: List<Media> = emptyList(),
)

sealed interface MoodIntent {
    data class ToggleMood(val mood: Mood) : MoodIntent
    data object ClearMoods : MoodIntent
    data object Apply : MoodIntent
}

sealed interface MoodEffect {
    data class OpenResults(val route: MoodResultsRoute) : MoodEffect
}

class MoodStore(
    private val repository: MediaRepository,
) : MviStore<MoodUiState, MoodIntent, MoodEffect>(MoodUiState()) {

    init {
        viewModelScope.launch {
            safeCall { repository.popular(MediaType.MOVIE).items }.onSuccess { reduce { copy(popularMovies = it) } }
        }
        viewModelScope.launch {
            safeCall { repository.popular(MediaType.TV).items }.onSuccess { reduce { copy(popularTv = it) } }
        }
    }

    override fun onIntent(intent: MoodIntent) {
        when (intent) {
            is MoodIntent.ToggleMood -> reduce {
                copy(selected = if (intent.mood in selected) selected - intent.mood else selected + intent.mood)
            }
            MoodIntent.ClearMoods -> reduce { copy(selected = emptySet()) }
            MoodIntent.Apply -> {
                val selected = currentState.selected
                if (selected.isNotEmpty()) postEffect(MoodEffect.OpenResults(MoodResultsRoute(selected.joinToString(",") { it.name })))
            }
        }
    }
}

@Composable
fun MoodScreen(onOpenMedia: (Media) -> Unit, onNavigate: (Any) -> Unit) {
    val store = rememberStore { MoodStore(it.mediaRepository) }
    val state by store.state.collectAsStateWithLifecycle()
    val selected = state.selected

    CollectEffects(store.effects) { effect ->
        when (effect) {
            is MoodEffect.OpenResults -> onNavigate(effect.route)
        }
    }

    val scrollState = rememberScrollState()
    ScrollToTopOnTabSelect { scrollState.scrollTo(0) }
    val scrolled by remember { derivedStateOf { scrollState.value > 0 } }

    Box(Modifier.fillMaxSize()) {
        Column(
            Modifier
                .fillMaxSize()
                .verticalScroll(scrollState)
                .statusBarsPadding()
                // Leaves room for the floating button as well as the nav bar.
                .padding(bottom = BottomBarSpace + 72.dp),
        ) {
            MoodHeader(selected = selected, onClear = { store.onIntent(MoodIntent.ClearMoods) })
            MoodGrid(
                selected = selected,
                onToggle = { store.onIntent(MoodIntent.ToggleMood(it)) },
                modifier = Modifier.padding(horizontal = 16.dp),
            )
            Spacer(Modifier.height(12.dp))
            MediaRow(
                title = "Popular Movies",
                items = state.popularMovies,
                onOpen = onOpenMedia,
                onSeeAll = { onNavigate(CategoryRoute(MediaType.MOVIE, "Popular Movies", CategoryList.POPULAR)) },
            )
            MediaRow(
                title = "Popular TV Shows",
                items = state.popularTv,
                onOpen = onOpenMedia,
                onSeeAll = { onNavigate(CategoryRoute(MediaType.TV, "Popular TV Shows", CategoryList.POPULAR)) },
            )
        }
        StatusBarScrim(visible = scrolled)

        // Appears as soon as a mood is picked, just above the nav bar, so it's reachable without scrolling.
        AnimatedVisibility(
            visible = selected.isNotEmpty(),
            enter = slideInVertically { it } + fadeIn(),
            exit = slideOutVertically { it } + fadeOut(),
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(start = 16.dp, end = 16.dp, bottom = BottomBarSpace),
        ) {
            PrimaryButton(
                text = if (selected.size == 1) "Find movies & shows" else "Find movies & shows · ${selected.size} moods",
                onClick = { store.onIntent(MoodIntent.Apply) },
                modifier = Modifier
                    .fillMaxWidth()
                    .shadow(12.dp, RoundedCornerShape(50)),
            )
        }
    }
}

/** Title, plus a line that spells out what the picked moods will find (or a prompt when none are picked). */
@Composable
private fun MoodHeader(selected: Set<Mood>, onClear: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(start = 16.dp, end = 4.dp, top = 20.dp, bottom = 14.dp),
        verticalAlignment = Alignment.Bottom,
    ) {
        Column(Modifier.weight(1f)) {
            Text(
                "How are you feeling?",
                style = MaterialTheme.typography.headlineSmall,
                modifier = Modifier.semantics { heading() },
            )
            Text(
                if (selected.isEmpty()) {
                    "Pick one or more moods"
                } else {
                    // Listed in the grid's order, so the line doesn't reshuffle as moods are added.
                    Mood.entries.filter { it in selected }.joinToString("  ·  ") { it.hint }
                },
                style = MaterialTheme.typography.bodyMedium,
                color = if (selected.isEmpty()) AppColors.TextSecondary else AppColors.Primary,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.padding(top = 4.dp),
            )
        }
        if (selected.isNotEmpty()) {
            TextButton(onClick = onClear) { Text("Clear", color = AppColors.Primary) }
        }
    }
}

private const val MoodColumns = 3

/** All moods as small equal tiles, three per row, so the whole set fits on one screen. */
@Composable
private fun MoodGrid(selected: Set<Mood>, onToggle: (Mood) -> Unit, modifier: Modifier = Modifier) {
    Column(modifier, verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Mood.entries.chunked(MoodColumns).forEach { row ->
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                row.forEach { mood ->
                    MoodTile(mood, selected = mood in selected, onClick = { onToggle(mood) }, modifier = Modifier.weight(1f))
                }
                // Keep a short last row's tiles the same width as the others.
                repeat(MoodColumns - row.size) { Spacer(Modifier.weight(1f)) }
            }
        }
    }
}

/** A small emoji over the mood's name. Selected: thin accent outline, faint tint, tiny check. */
@Composable
private fun MoodTile(mood: Mood, selected: Boolean, onClick: () -> Unit, modifier: Modifier = Modifier) {
    val shape = RoundedCornerShape(12.dp)
    val background by animateColorAsState(
        if (selected) AppColors.Primary.copy(alpha = 0.10f) else AppColors.Surface.copy(alpha = 0.7f),
        label = "moodTileBackground",
    )
    val border by animateColorAsState(
        if (selected) AppColors.Primary else AppColors.Outline.copy(alpha = 0.12f),
        label = "moodTileBorder",
    )
    Box(
        modifier
            .height(76.dp)
            .clip(shape)
            .background(background)
            .border(1.dp, border, shape)
            // An on/off choice, so screen readers announce it as a checkbox with its state.
            .toggleable(value = selected, role = Role.Checkbox, onValueChange = { onClick() })
            .semantics { contentDescription = "${mood.label}: ${mood.hint}" },
    ) {
        Column(
            Modifier
                .fillMaxSize()
                .padding(horizontal = 6.dp, vertical = 8.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
        ) {
            Text(mood.emoji, style = MaterialTheme.typography.titleLarge)
            Text(
                mood.label,
                style = MaterialTheme.typography.bodySmall.copy(fontSize = 13.sp, lineHeight = 15.sp),
                fontWeight = FontWeight.SemiBold,
                color = if (selected) AppColors.Primary else AppColors.TextPrimary,
                textAlign = TextAlign.Center,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.padding(top = 4.dp),
            )
        }
        if (selected) {
            Icon(
                AppIcons.Check,
                contentDescription = null,
                tint = AppColors.Primary,
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(5.dp)
                    .size(14.dp),
            )
        }
    }
}
