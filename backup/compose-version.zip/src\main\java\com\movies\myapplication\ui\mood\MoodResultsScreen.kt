package com.movies.myapplication.ui.mood

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.movies.myapplication.data.model.Media
import com.movies.myapplication.data.model.MediaType
import com.movies.myapplication.data.model.toFilter
import com.movies.myapplication.ui.browse.BrowseIntent
import com.movies.myapplication.ui.browse.BrowseStore
import com.movies.myapplication.ui.components.PagedMediaGrid
import com.movies.myapplication.ui.components.Pill
import com.movies.myapplication.ui.components.TopBar
import com.movies.myapplication.ui.navigation.MoodResultsRoute
import com.movies.myapplication.ui.rememberStore

/** Results for the selected moods, with Movies and TV Shows tabs (each uses its own TMDB genres). */
@Composable
fun MoodResultsScreen(route: MoodResultsRoute, onOpenMedia: (Media) -> Unit, onBack: () -> Unit) {
    val moods = route.moodSet()
    var type by rememberSaveable { mutableStateOf(MediaType.MOVIE) }
    // One store per tab, so each keeps its results and paging when switching back and forth.
    val movies = rememberStore(key = "mood-movies") {
        BrowseStore(it.mediaRepository, MediaType.MOVIE, moods.toFilter(MediaType.MOVIE))
    }
    val shows = rememberStore(key = "mood-tv") {
        BrowseStore(it.mediaRepository, MediaType.TV, moods.toFilter(MediaType.TV))
    }

    Column(Modifier.fillMaxSize()) {
        TopBar(moods.joinToString(" + ") { "${it.emoji} ${it.label}" }, onBack)
        Row(
            Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Pill("Movies", selected = type == MediaType.MOVIE, onClick = { type = MediaType.MOVIE })
            Pill("TV Shows", selected = type == MediaType.TV, onClick = { type = MediaType.TV })
        }
        key(type) {
            val store = if (type == MediaType.MOVIE) movies else shows
            val state by store.state.collectAsStateWithLifecycle()
            PagedMediaGrid(
                content = state,
                onLoadMore = { store.onIntent(BrowseIntent.LoadMore) },
                onRetry = { store.onIntent(BrowseIntent.Retry) },
                onOpenMedia = onOpenMedia,
            )
        }
    }
}
