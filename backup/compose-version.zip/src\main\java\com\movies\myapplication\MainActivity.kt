package com.movies.myapplication

import android.graphics.Color
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.remember
import com.movies.myapplication.ui.LocalAppContainer
import com.movies.myapplication.ui.components.LocalTextFieldArea
import com.movies.myapplication.ui.components.TextFieldArea
import com.movies.myapplication.ui.navigation.MovieAppRoot
import com.movies.myapplication.ui.theme.MovieTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(Color.TRANSPARENT),
        )
        val container = (application as MovieApp).container
        setContent {
            CompositionLocalProvider(
                LocalAppContainer provides container,
                LocalTextFieldArea provides remember { TextFieldArea() },
            ) {
                MovieTheme {
                    MovieAppRoot()
                }
            }
        }
    }
}
