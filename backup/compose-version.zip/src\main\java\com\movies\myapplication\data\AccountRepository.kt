package com.movies.myapplication.data

import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.core.stringPreferencesKey
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.io.IOException

/** The signed-in user, from Google or a guest session. Only display details are kept; no tokens are stored. */
data class Account(val name: String, val email: String?, val photoUrl: String?, val isGuest: Boolean)

class AccountRepository(private val dataStore: DataStore<Preferences>, private val scope: CoroutineScope) {

    val account: StateFlow<Account?> = dataStore.data
        .catch { if (it is IOException) emit(emptyPreferences()) else throw it }
        .map { prefs ->
            prefs[NAME]?.let { name -> Account(name, prefs[EMAIL], prefs[PHOTO], prefs[GUEST] ?: false) }
        }
        .stateIn(scope, SharingStarted.Eagerly, null)

    fun signIn(account: Account) {
        scope.launch {
            dataStore.edit { prefs ->
                prefs.clear()
                prefs[NAME] = account.name
                prefs[GUEST] = account.isGuest
                account.email?.let { prefs[EMAIL] = it }
                account.photoUrl?.let { prefs[PHOTO] = it }
            }
        }
    }

    fun signOut() {
        scope.launch { dataStore.edit { it.clear() } }
    }

    private companion object {
        val NAME = stringPreferencesKey("name")
        val EMAIL = stringPreferencesKey("email")
        val PHOTO = stringPreferencesKey("photo")
        val GUEST = booleanPreferencesKey("guest")
    }
}
