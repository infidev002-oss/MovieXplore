package com.movies.myapplication.ui.category

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import com.movies.myapplication.data.MediaRepository
import com.movies.myapplication.data.model.DiscoverFilter
import com.movies.myapplication.data.model.Media
import com.movies.myapplication.data.model.PageResult
import com.movies.myapplication.ui.components.PagedContent
import com.movies.myapplication.ui.components.PagedMediaGrid
import com.movies.myapplication.ui.components.TopBar
import com.movies.myapplication.ui.mvi.MviStore
import com.movies.myapplication.ui.navigation.CategoryList
import com.movies.myapplication.ui.navigation.CategoryRoute
import com.movies.myapplication.ui.rememberStore
import com.movies.myapplication.ui.safeCall
import com.movies.myapplication.ui.toUserMessage
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch

data class CategoryUiState(
    override val items: List<Media> = emptyList(),
    override val isLoading: Boolean = true,
    override val isLoadingMore: Boolean = false,
    override val error: String? = null,
    /** Last page loaded; 0 before the first one arrives. */
    val page: Int = 0,
    val hasMore: Boolean = true,
) : PagedContent

sealed interface CategoryIntent {
    data object LoadMore : CategoryIntent
    data object Retry : CategoryIntent
}

class CategoryStore(
    private val repository: MediaRepository,
    private val route: CategoryRoute,
) : MviStore<CategoryUiState, CategoryIntent, Nothing>(CategoryUiState()) {

    private var job: Job? = null

    init {
        loadNextPage()
    }

    override fun onIntent(intent: CategoryIntent) {
        when (intent) {
            // A failed page is not counted as loaded, so retrying is just loading the next page again.
            CategoryIntent.LoadMore, CategoryIntent.Retry -> loadNextPage()
        }
    }

    private fun loadNextPage() {
        val current = currentState
        if (!current.hasMore || job?.isActive == true) return
        val firstPage = current.page == 0
        job = viewModelScope.launch {
            reduce { copy(isLoading = firstPage, isLoadingMore = !firstPage, error = null) }
            safeCall { fetch(current.page + 1) }
                .onSuccess { result ->
                    reduce {
                        copy(
                            items = (items + result.items).distinctBy { it.key },
                            page = result.page,
                            hasMore = result.hasMore,
                            isLoading = false,
                            isLoadingMore = false,
                        )
                    }
                }
                .onFailure { e ->
                    reduce { copy(isLoading = false, isLoadingMore = false, error = e.toUserMessage()) }
                }
        }
    }

    private suspend fun fetch(page: Int): PageResult = when (route.list) {
        CategoryList.GENRE -> repository.discover(route.type, DiscoverFilter(genreIds = setOf(route.genreId)), page)
        CategoryList.TRENDING -> repository.trending(route.type, page)
        CategoryList.POPULAR -> repository.popular(route.type, page)
        CategoryList.TOP_RATED -> repository.topRated(route.type, page)
    }
}

/** A category's titled poster grid, e.g. "Action" or "Trending Movies". */
@Composable
fun CategoryScreen(route: CategoryRoute, onOpenMedia: (Media) -> Unit, onBack: () -> Unit) {
    val store = rememberStore { CategoryStore(it.mediaRepository, route) }
    val state by store.state.collectAsStateWithLifecycle()

    Column(Modifier.fillMaxSize()) {
        TopBar(route.title, onBack)
        PagedMediaGrid(
            content = state,
            onLoadMore = { store.onIntent(CategoryIntent.LoadMore) },
            onRetry = { store.onIntent(CategoryIntent.Retry) },
            onOpenMedia = onOpenMedia,
        )
    }
}
