package com.movies.myapplication.ui.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.unit.dp
import com.movies.myapplication.data.model.Media
import com.movies.myapplication.ui.theme.AppColors
import kotlinx.coroutines.flow.filter

/** What a paged poster grid needs to know about its screen's state. */
interface PagedContent {
    val items: List<Media>
    val isLoading: Boolean
    val isLoadingMore: Boolean
    val error: String?
}

/** 3-column poster grid with loading/error/empty states and infinite scroll. */
@Composable
fun PagedMediaGrid(
    content: PagedContent,
    onLoadMore: () -> Unit,
    onRetry: () -> Unit,
    onOpenMedia: (Media) -> Unit,
) {
    val gridState = rememberLazyGridState()
    val focusManager = LocalFocusManager.current
    val error = content.error

    LoadMoreEffect(gridState, onLoadMore)
    // Taps are handled app-wide; scrolling is not a tap, so hide the keyboard here when browsing results.
    LaunchedEffect(gridState) {
        snapshotFlow { gridState.isScrollInProgress }
            .filter { it }
            .collect { focusManager.clearFocus() }
    }

    Box(Modifier.fillMaxSize()) {
        when {
            content.items.isNotEmpty() -> LazyVerticalGrid(
                columns = GridCells.Fixed(3),
                state = gridState,
                contentPadding = PaddingValues(start = 12.dp, end = 12.dp, top = 4.dp, bottom = 24.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalArrangement = Arrangement.spacedBy(18.dp),
                modifier = Modifier
                    .fillMaxSize()
                    .navigationBarsPadding(),
            ) {
                items(content.items, key = { it.key }) { media ->
                    PosterCard(
                        media = media,
                        isSaved = false,
                        onClick = { onOpenMedia(media) },
                        onToggleSave = null,
                    )
                }
                if (content.isLoadingMore) {
                    item(span = { GridItemSpan(maxLineSpan) }) {
                        Box(
                            Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            contentAlignment = Alignment.Center,
                        ) {
                            CircularProgressIndicator(color = AppColors.Primary, modifier = Modifier.size(28.dp))
                        }
                    }
                }
            }
            content.isLoading -> PosterGridSkeleton()
            error != null -> MessageState(error, onRetry = onRetry)
            else -> MessageState("No results found. Try a different search or filter.")
        }
        if (content.isLoading && content.items.isNotEmpty()) {
            LinearProgressIndicator(
                color = AppColors.Primary,
                trackColor = AppColors.SurfaceHigh,
                modifier = Modifier
                    .fillMaxWidth()
                    .align(Alignment.TopCenter),
            )
        }
    }
}
