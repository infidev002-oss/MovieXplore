package com.movies.myapplication.ui.navigation

import androidx.annotation.Keep
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.dropUnlessResumed
import androidx.navigation.NavDestination
import androidx.navigation.NavDestination.Companion.hasRoute
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.toRoute
import com.movies.myapplication.data.model.Genre
import com.movies.myapplication.data.model.Media
import com.movies.myapplication.data.model.MediaType
import com.movies.myapplication.data.model.Mood
import com.movies.myapplication.ui.browse.BrowseScreen
import com.movies.myapplication.ui.category.CategoryScreen
import com.movies.myapplication.ui.components.LocalTextFieldArea
import com.movies.myapplication.ui.components.dismissKeyboardOnTapOutside
import com.movies.myapplication.ui.components.glass
import dev.chrisbanes.haze.HazeState
import dev.chrisbanes.haze.hazeSource
import dev.chrisbanes.haze.rememberHazeState
import com.movies.myapplication.ui.details.DetailsScreen
import com.movies.myapplication.ui.details.EpisodeScreen
import com.movies.myapplication.ui.details.SeasonScreen
import com.movies.myapplication.ui.home.HomeScreen
import com.movies.myapplication.ui.mood.MoodResultsScreen
import com.movies.myapplication.ui.mood.MoodScreen
import com.movies.myapplication.ui.person.PersonScreen
import com.movies.myapplication.ui.profile.ProfileScreen
import com.movies.myapplication.ui.theme.AppBackground
import com.movies.myapplication.ui.theme.AppColors
import com.movies.myapplication.ui.theme.AppIcons
import com.movies.myapplication.ui.watchlist.WatchlistScreen
import kotlinx.serialization.Serializable

@Serializable data object HomeRoute
@Serializable data object WatchlistRoute
@Serializable data object MoodRoute
@Serializable data object ProfileRoute
@Serializable data class DetailsRoute(val id: Int, val type: MediaType)
/** [backdropPath] is the show's backdrop, shown for episodes that have no still image yet. */
@Serializable data class SeasonRoute(val tvId: Int, val showName: String, val season: Int, val backdropPath: String? = null)
@Serializable data class EpisodeRoute(
    val tvId: Int,
    val showName: String,
    val season: Int,
    val episode: Int,
    val backdropPath: String? = null,
)
@Serializable data class PersonRoute(val id: Int)

@Serializable
data class BrowseRoute(val type: MediaType, val title: String? = null)

/** Which TMDB list a category screen shows. Kept from R8 renaming: routes resolve enum arguments by class name. */
@Keep
enum class CategoryList { GENRE, TRENDING, POPULAR, TOP_RATED }

/** A titled poster grid for one category; [genreId] applies only to [CategoryList.GENRE]. */
@Serializable
data class CategoryRoute(val type: MediaType, val title: String, val list: CategoryList, val genreId: Int = 0) {
    companion object {
        fun genre(type: MediaType, genre: Genre) = CategoryRoute(type, genre.name, CategoryList.GENRE, genre.id)
    }
}

/** [moods] holds [Mood] names, comma-separated. */
@Serializable
data class MoodResultsRoute(val moods: String) {
    fun moodSet(): Set<Mood> = moods.split(',').mapNotNull { name -> Mood.entries.firstOrNull { it.name == name } }.toSet()
}

private data class Tab(val route: Any, val icon: ImageVector, val label: String)

private val tabs = listOf(
    Tab(HomeRoute, AppIcons.Home, "Home"),
    Tab(WatchlistRoute, AppIcons.Bookmark, "Watchlist"),
    Tab(MoodRoute, AppIcons.Mood, "Mood"),
    Tab(ProfileRoute, AppIcons.Person, "Profile"),
)

@Composable
fun MovieAppRoot() {
    val navController = rememberNavController()
    val currentEntry by navController.currentBackStackEntryAsState()
    val openMedia: (Media) -> Unit = { navController.navigate(DetailsRoute(it.id, it.type)) }
    val navigate: (Any) -> Unit = { navController.navigate(it) }
    val focusManager = LocalFocusManager.current
    val textFieldArea = LocalTextFieldArea.current
    // Screen content is the source the floating nav bar blurs.
    val hazeState = rememberHazeState()
    // Bumped on every bottom-bar tap, so the chosen tab opens at its top (see ScrollToTopOnTabSelect).
    var tabSelections by rememberSaveable { mutableIntStateOf(0) }

    // Never carry an open keyboard over to another screen.
    LaunchedEffect(currentEntry?.id) { focusManager.clearFocus() }

    Box(
        Modifier
            .fillMaxSize()
            .background(AppBackground)
            .dismissKeyboardOnTapOutside(focusManager, textFieldArea),
    ) {
        CompositionLocalProvider(LocalTabSelections provides tabSelections) {
            NavHost(
                navController = navController,
                startDestination = HomeRoute,
                // Opening a screen slides it in a little from the right; going back reverses it.
                // Switching bottom-bar tabs only cross-fades, since tabs are siblings, not a stack.
                enterTransition = {
                    if (targetState.destination.isTab()) fadeIn(tween(200)) else fadeIn(tween(250)) + slideInHorizontally(tween(250)) { it / 8 }
                },
                exitTransition = { fadeOut(tween(200)) },
                popEnterTransition = { fadeIn(tween(250)) },
                popExitTransition = {
                    if (initialState.destination.isTab()) fadeOut(tween(200)) else fadeOut(tween(250)) + slideOutHorizontally(tween(250)) { it / 8 }
                },
                modifier = Modifier.hazeSource(hazeState),
            ) {
                composable<HomeRoute> {
                    HomeScreen(onOpenMedia = openMedia, onNavigate = navigate)
                }
                composable<WatchlistRoute> {
                    WatchlistScreen(onOpenMedia = openMedia)
                }
                composable<MoodRoute> {
                    MoodScreen(onOpenMedia = openMedia, onNavigate = navigate)
                }
                composable<ProfileRoute> {
                    ProfileScreen()
                }
                composable<BrowseRoute> { entry ->
                    BrowseScreen(
                        route = entry.toRoute(),
                        onOpenMedia = openMedia,
                        onNavigate = navigate,
                        onBack = dropUnlessResumed { navController.popBackStack() },
                    )
                }
                composable<CategoryRoute> { entry ->
                    CategoryScreen(
                        route = entry.toRoute(),
                        onOpenMedia = openMedia,
                        onBack = dropUnlessResumed { navController.popBackStack() },
                    )
                }
                composable<MoodResultsRoute> { entry ->
                    MoodResultsScreen(
                        route = entry.toRoute(),
                        onOpenMedia = openMedia,
                        onBack = dropUnlessResumed { navController.popBackStack() },
                    )
                }
                composable<DetailsRoute> { entry ->
                    DetailsScreen(
                        route = entry.toRoute(),
                        onBack = dropUnlessResumed { navController.popBackStack() },
                        onOpenMedia = openMedia,
                        onNavigate = navigate,
                    )
                }
                composable<SeasonRoute> { entry ->
                    SeasonScreen(
                        route = entry.toRoute(),
                        onBack = dropUnlessResumed { navController.popBackStack() },
                        onNavigate = navigate,
                    )
                }
                composable<EpisodeRoute> { entry ->
                    EpisodeScreen(
                        route = entry.toRoute(),
                        onBack = dropUnlessResumed { navController.popBackStack() },
                        onNavigate = navigate,
                    )
                }
                composable<PersonRoute> { entry ->
                    PersonScreen(
                        route = entry.toRoute(),
                        onBack = dropUnlessResumed { navController.popBackStack() },
                        onOpenMedia = openMedia,
                    )
                }
            }
        }

        val destination = currentEntry?.destination
        AnimatedVisibility(
            visible = destination?.isTab() == true,
            enter = fadeIn() + slideInVertically { it / 2 },
            exit = fadeOut() + slideOutVertically { it / 2 },
            modifier = Modifier.align(Alignment.BottomCenter),
        ) {
            FloatingNavBar(destination, hazeState) { tab ->
                tabSelections++
                navController.navigate(tab.route) {
                    popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                    launchSingleTop = true
                    restoreState = true
                }
            }
        }
    }
}

private fun NavDestination.isTab() = tabs.any { hasRoute(it.route::class) }

@Composable
private fun FloatingNavBar(destination: NavDestination?, hazeState: HazeState, onSelect: (Tab) -> Unit) {
    // Tab screens keep FloatingNavBarHeight clear for this bar; update it if these sizes change.
    Row(
        Modifier
            .navigationBarsPadding()
            .padding(bottom = 12.dp)
            .glass(hazeState, RoundedCornerShape(50))
            .padding(horizontal = 16.dp, vertical = 10.dp),
        horizontalArrangement = Arrangement.spacedBy(20.dp),
    ) {
        tabs.forEach { tab ->
            val selected = destination?.hasRoute(tab.route::class) == true
            Box(
                Modifier
                    .size(52.dp)
                    .clip(CircleShape)
                    .background(if (selected) Color.White else Color.White.copy(alpha = 0.06f))
                    .border(1.dp, Color.White.copy(alpha = if (selected) 0f else 0.15f), CircleShape)
                    .clickable { onSelect(tab) },
                contentAlignment = Alignment.Center,
            ) {
                Icon(
                    tab.icon,
                    contentDescription = tab.label,
                    tint = if (selected) AppColors.Background else AppColors.TextPrimary,
                    modifier = Modifier.size(26.dp),
                )
            }
        }
    }
}
