package com.movies.myapplication.ui.details

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import com.movies.myapplication.data.MediaRepository
import com.movies.myapplication.data.model.Episode
import com.movies.myapplication.data.model.SeasonInfo
import com.movies.myapplication.ui.components.LoadingState
import com.movies.myapplication.ui.components.MessageState
import com.movies.myapplication.ui.components.Pill
import com.movies.myapplication.ui.components.TopBar
import com.movies.myapplication.ui.formatDate
import com.movies.myapplication.ui.formatRuntime
import com.movies.myapplication.ui.mvi.MviStore
import com.movies.myapplication.ui.navigation.EpisodeRoute
import com.movies.myapplication.ui.navigation.SeasonRoute
import com.movies.myapplication.ui.rememberStore
import com.movies.myapplication.ui.safeCall
import com.movies.myapplication.ui.theme.AppColors
import com.movies.myapplication.ui.toUserMessage
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch

data class SeasonUiState(
    val seasons: List<SeasonInfo> = emptyList(),
    val selected: Int,
    val episodes: List<Episode> = emptyList(),
    val isLoading: Boolean = true,
    val error: String? = null,
)

sealed interface SeasonIntent {
    data class Select(val number: Int) : SeasonIntent
    data object Retry : SeasonIntent
}

class SeasonStore(
    private val repository: MediaRepository,
    private val route: SeasonRoute,
) : MviStore<SeasonUiState, SeasonIntent, Nothing>(SeasonUiState(selected = route.season)) {

    private var job: Job? = null

    init {
        viewModelScope.launch {
            safeCall { repository.seasons(route.tvId) }.onSuccess { seasons -> reduce { copy(seasons = seasons) } }
        }
        select(route.season)
    }

    override fun onIntent(intent: SeasonIntent) {
        when (intent) {
            is SeasonIntent.Select -> select(intent.number)
            SeasonIntent.Retry -> select(currentState.selected)
        }
    }

    private fun select(number: Int) {
        job?.cancel()
        reduce { copy(selected = number, isLoading = true, error = null) }
        job = viewModelScope.launch {
            safeCall { repository.episodes(route.tvId, number) }
                .onSuccess { episodes -> reduce { copy(episodes = episodes, isLoading = false) } }
                .onFailure { e -> reduce { copy(episodes = emptyList(), isLoading = false, error = e.toUserMessage()) } }
        }
    }
}

@Composable
fun SeasonScreen(route: SeasonRoute, onBack: () -> Unit, onNavigate: (Any) -> Unit) {
    val store = rememberStore { SeasonStore(it.mediaRepository, route) }
    val state by store.state.collectAsStateWithLifecycle()
    val error = state.error

    Column(Modifier.fillMaxSize()) {
        TopBar(route.showName, onBack, centered = true)
        Text("Choose Season", style = MaterialTheme.typography.titleLarge, modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp))
        LazyRow(
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            items(state.seasons, key = { it.number }) { season ->
                Pill(season.name.ifBlank { "Season ${season.number}" }, selected = season.number == state.selected, onClick = { store.onIntent(SeasonIntent.Select(season.number)) })
            }
        }
        when {
            state.isLoading -> LoadingState()
            error != null -> MessageState(error, onRetry = { store.onIntent(SeasonIntent.Retry) })
            state.episodes.isEmpty() -> MessageState("No episodes announced yet.")
            else -> {
                Text(
                    "Season ${state.selected}, ${state.episodes.size} Episodes",
                    style = MaterialTheme.typography.titleLarge,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp),
                )
                LazyColumn(
                    contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 24.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp),
                    modifier = Modifier.navigationBarsPadding(),
                ) {
                    items(state.episodes, key = { it.id }) { episode ->
                        EpisodeRow(episode, route.backdropPath) {
                            onNavigate(EpisodeRoute(route.tvId, route.showName, state.selected, episode.number, route.backdropPath))
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun EpisodeRow(episode: Episode, showBackdropPath: String?, onClick: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Thumbnail(episode.stillUrl(showBackdropPath), episode.name, Modifier.width(150.dp))
        Column(Modifier.padding(start = 14.dp)) {
            Text(episode.name, style = MaterialTheme.typography.titleMedium, maxLines = 2, overflow = TextOverflow.Ellipsis)
            formatRuntime(episode.runtime)?.let {
                Text(it, style = MaterialTheme.typography.bodyMedium, color = AppColors.Primary, modifier = Modifier.padding(top = 2.dp))
            }
            formatDate(episode.airDate)?.let {
                Text(it, style = MaterialTheme.typography.bodyMedium, color = AppColors.Primary)
            }
        }
    }
}
